﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.consumer.DataEntities
{
    public class ConsumerPwa
    {
        //[BsonId]
        //public ObjectId _id { get; set; }
        public object consumerProfile { get; set; }
    }
}

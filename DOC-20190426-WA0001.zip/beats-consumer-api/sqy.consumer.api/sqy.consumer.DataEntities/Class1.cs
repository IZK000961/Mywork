﻿using System;

namespace sqy.consumer.DataEntities
{
    public class Class1
    {
    }
}

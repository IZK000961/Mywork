﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.consumer.DataEntities
{
    public enum DEConsumerRMCallValues
    {
        GetRMDetails = 1,
        AddRMChangeRequest = 2,
        GetUpcomingActivity=3,
        GetRecentActivity=4,
        AddResecheduleActivity=5,
        UpdateActivityFeedback=6,
        GetRMChangeReason=7,
        GetRMchangeSubReason=8,
        InsertRMRating=9,
        InsertRMRatingFeedback=10,
        GetLocation=11
    }
    public class DEConsumerRM
    {
        public DEConsumerRMCallValues CallValue { get; set; }
        public int? LeadID { get; set; }
        public string lead_hash { get; set; }
        public int ActivityId { get; set; }
        public int RMId { get; set; }
        public string ChangeReason { get; set; }
        public string SubReason { get; set; }
        public string Remarks { get; set; }
        public DateTime? NextInteractionDate { get; set; }
        public int Updatedby { get; set; }
        public int FeedbackRatings { get; set; }
        public int PageNo { get; set; } = 1;
        public int Limit { get; set; } =1;
        public bool ChangeRM { get; set; }
        //public int LeadID { get; set; }
        public string Type { get; set; }

        // ----------------- RM Rating -------------------// 
        public int RmRatingId { get; set; }
        public int RatingID { get; set; }
        public string RatingDesc { get; set; }
        public double RatingValue { get; set; }

        // ----------------- RM Rating Feedback-------------------// 
        public int FeedbackID { get; set; }
        public string FeedbackDesc { get; set; }

        public DataSet dsResult { get; set; }
    }
    public class DEConsumerRMReasonResponse
    {
        public int ReasonId { get; set; }
        public string ReasonName { get; set; }
        public string Statement { get; set; }
        public List<DEConsumerRMSubReasonResponse> SubReason { get; set; }
    }
    public class DEConsumerRMSubReasonResponse
    {
        public int SubReasonId { get; set; }
        public string SubReasonName { get; set; }
    }

    public class DERMRating
    {
        public int rmRatingId { get; set; }
        public string leadID { get; set; }
        public string lead_hash { get; set; }
        public int activityID { get; set; }
        public int rMID { get; set; }
        public int ratingID { get; set; }
        public string ratingDesc { get; set; }
        public double RatingValue { get; set; }
        public string remarks { get; set; }
        public bool ChangeRM { get; set; }
        public List<DERMFeedback> rMFeedback { get; set; }
    }
    public class DERMFeedback
    {
        public int id { get; set; }
        public int rmRatingId { get; set; }
        public int feedbackID { get; set; }
        public string feedbackDesc { get; set; }
    }
    public class GetRecentActivityResponseDTO
    {
        public int MaxNumberOfPages { get; set; }
        public int CurrentPage { get; set; }
        //public string FilterInfo { get; set; }
        //public List<GetMyLeadsLeadResponseDTO> filterRes { get; set; }
    }
    public class GetRecentActivityRequestDTO
    {
        public string lead_id { get; set; }
        public int pageNo { get; set; } = 1;
        public int limit { get; set; } = 10;
    }

}

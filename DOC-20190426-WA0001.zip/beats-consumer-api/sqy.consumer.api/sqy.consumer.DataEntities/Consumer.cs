﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.consumer.DataEntities
{
    public class Consumer
    {
        [BsonId]
        public ObjectId _id { get; set; }
        [BsonElement]
        public int id { get; set; }
        [BsonElement]
        public string name { get; set; }
        public string email { get; set; }
        public string country_code { get; set; }
        public string mobile { get; set; }
        public string client_city { get; set; }
        public string client_country { get; set; }
        public string pincode { get; set; }
        public salutation salutation { get; set; }
        public string dob { get; set; }
        public DateTime firstJourney { get; set; }
        public List<Languages> languages { get; set; }
        public education education { get; set; }
        public investmentDetails investmentDetails { get; set; }
        public incomeDetails incomeDetails { get; set; }
        public occupation occupation { get; set; }
        public PrefferedLocations PrefferedLocations { get; set; }
        public purchaseIntent purchaseIntent { get; set; }
        public List<lead> lead { get; set; }
        public List<interests> interests { get; set; }
        public LastKnown last_known { get; set; }
        public DateTime created_on { get; set; } = DateTime.Now;
        public string anniversary_date { get; set; }
        [BsonDateTimeOptions]
        public DateTime updated_on { get; set; } 
        [BsonDateTimeOptions]
        public DateTime agentUpdated_on { get; set; }
        public int updatedBy { get; set; }
        public List<PageStatus> PageStatus { get; set; }
        public int profileStatus { get; set; }
        public DateTime FirstConsumeDate { get; set; }
        public creditScores CreditScore { get; set; }
        //public string CreditScorePath { get; set; }
    }
    public class lead
    {
        public int lead_id { get; set; }
        public string segment { get; set; }
        public string lead_hash { get; set; }
    }
    public class interests
    {
        [BsonId]
        public ObjectId _id { get; set; }
        [BsonElement]
        public int project_id { get; set; }
        public string project_name { get; set; }
        public string project_address { get; set; }
        public string project_city { get; set; }
        public int project_city_id { get; set; }
        public int project_country_id { get; set; }
        public DateTime date_added { get; set; }
        public string project_flagship { get; set; }
    }
    public class LastKnown
    {
        public string client_ip { get; set; }
        public string user_agent { get; set; }
    }
    public class custreqdto
    {
        public int id { get; set; }
        public int lead_id { get; set; }
        public int project_id { get; set; }
    }
    public class Languages
    {
        public int language_id { get; set; }
        public string language { get; set; }
    }
    public class education
    {
        public int education_id { get; set; }
        public string value { get; set; }
    }
    public class salutation
    {
        public int salutation_id { get; set; }
        public string value { get; set; }
    }
    public class investmentDetails
    {
        public Investment investment { get; set; }
        public currency currency { get; set; }
        public int downpayment { get; set; }
    }

    public class incomeDetails
    {
        public currency currency { get; set; }
        public Income income { get; set; }
    }

    public class Investment
    {
        public int Investment_id { get; set; }
        public string value { get; set; }
    }
    public class currency
    {
        public int currency_id { get; set; }
        public string value { get; set; }
    }
    public class Income
    {
        public int income_id { get; set; }
        public string value { get; set; }
    }

    public class occupation
    {
        public employment employment { get; set; }
        public designation designation { get; set; }
        public company company { get; set; }
        public professionType professionType { get; set; }
        public businessNature businessNature { get; set; }
        public int yearsInProfession { get; set; }
        public string businessName { get; set; }
    }
    public class employment
    {
        public int employment_id { get; set; }
        public string value { get; set; }
    }
    public class designation
    {
        public int designation_id { get; set; }
        public string value { get; set; }
    }
    public class company
    {
        public int company_id { get; set; }
        public string name { get; set; }
    }
    public class professionType
    {
        public int profession_id { get; set; }
        public string value { get; set; }
    }
    public class businessNature
    {
        public int businessNature_id { get; set; }
        public string value { get; set; }
    }

    public class purchaseIntent
    {
        public intentType intentType { get; set; }
        public List<intents> intents { get; set; }
    }
    public class intentType
    {
        public int intentType_id { get; set; }
        public string value { get; set; }
    }
    public class intents
    {
        public int intents_id { get; set; }
        public string value { get; set; }
    }

    public class PrefferedLocations
    {
        public country country { get; set; }
        public city city { get; set; }
        public List<locations> locations { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
    }
    public class country
    {
        public int country_id { get; set; }
        public string text { get; set; }
    }
    public class city
    {
        public int city_id { get; set; }
        public string text { get; set; }
    }
    public class locations
    {
        public int location_id { get; set; }
        public string location_name { get; set; }
        public bool selected { get; set; }
        public List<Sublocations> sublocations { get; set; }
    }
    public class Sublocations
    {
        public int location_id { get; set; }
        public string location_name { get; set; }
    }
    public class PageStatus
    {
        public int PersonalInfo { get; set; } = 0;
        public int Property { get; set; } = 0;
        public int Location { get; set; } = 0;
        public int Employment { get; set; } = 0;
    }

    public class creditScores
    {
        public int creditScore { get; set; }
        public string creditScorePath { get; set; }
        public string creditScoreStatus { get; set; }
        public string creditScoreResponse { get; set; }
        public string creditScoreCheckedOn { get; set; }
        public string creditScoreCheckedCount { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.consumer.DataEntities
{
    public enum DEConsumerLoginCallValues
    {
        GenrateOTP = 1,
        ValidateOTP = 2,
        GetLocation=3,
        resendotp=4,
        ValidateToken=5
    }

    public class DEConsumerLogin
    {
        public DEConsumerLoginCallValues CallValue { get; set; }
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public int RequestId { get; set; }
        public int OTP { get; set; }
        public DataSet dsResult { get; set; }
        public int SegmentId { get; set; }
        public string Token { get; set; }
    }
    public class DEConsumerLoginResponse
    {
        public int RequestId { get; set; }
        public string OTP { get; set; }
    }
}

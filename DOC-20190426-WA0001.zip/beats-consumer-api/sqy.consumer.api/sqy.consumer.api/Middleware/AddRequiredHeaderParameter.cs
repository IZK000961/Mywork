﻿using Microsoft.AspNetCore.Authorization;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api.Middleware
{
    public class AddAuthorizationHeaderParameterOperationFilter : IOperationFilter
    {
        public void Apply(Operation operation, OperationFilterContext context)
        {
            if (operation.Parameters == null)
                operation.Parameters = new List<IParameter>();
            var attrs = context.ApiDescription.ActionAttributes();
            var ctrlAttrs = context.ApiDescription.ControllerAttributes();
            // var isAuthorized = attrs.Any(filter => filter is IAuthorizationFilter);

            var allowAnonymous = attrs.Any(filter => filter is IAllowAnonymous);
            if (!allowAnonymous)
            {
                operation.Parameters.Add(new NonBodyParameter
                {
                    Name = "authorization",
                    In = "header",
                    Type = "string",
                    Required = true
                });
            }
        }
    }
}

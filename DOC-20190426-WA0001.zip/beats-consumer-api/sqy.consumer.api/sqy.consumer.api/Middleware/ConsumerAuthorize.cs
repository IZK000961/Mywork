﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Primitives;
using sqy.consumer.DataAccess;
using sqy.consumer.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api.Middleware
{
    public class ConsumerAuthorizeAttribute: TypeFilterAttribute
    {
        public ConsumerAuthorizeAttribute()
            : base(typeof(ConsumerAuthorizeAttributeExecutor))
        {

        }
        private class ConsumerAuthorizeAttributeExecutor: IAsyncActionFilter
        {
            private readonly IConfiguration _configuration;
            public ConsumerAuthorizeAttributeExecutor(IConfiguration configuration)
            {
                _configuration = configuration;
            }
            public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
            {
                try
                {
                    var controllerActionDescriptor = context.ActionDescriptor as ControllerActionDescriptor;
                    object[] actionAttributes = new object[] { };
                    if (controllerActionDescriptor != null)
                    {
                        actionAttributes = controllerActionDescriptor.MethodInfo.GetCustomAttributes(inherit: true);
                    }
                    var isAnonymous = actionAttributes.Any(filter => filter is IAllowAnonymous);
                    var token = context.HttpContext.Request.Cookies["_users"];
                    if (!string.IsNullOrEmpty(token))
                    {
                        DAConsumerLogin da = new DAConsumerLogin();
                        DEConsumerLogin de = new DEConsumerLogin()
                        {

                            CallValue = DEConsumerLoginCallValues.ValidateToken,
                            Token = token
                        };
                        var ds = da.Execute(de);
                        if (ds.Tables.Count == 0)
                        {
                            context.HttpContext.Response.StatusCode = 403;
                            return;
                        }
                    }
                    else
                    {
                        context.HttpContext.Response.StatusCode = 403;
                        return;
                    }
                    await next();
                }
                catch (Exception ex)
                {
                    context.Result = new JsonResult(new
                    {
                        Status = 0,
                        Message = ex.Message,
                        Data = new { }
                    });
                    return;
                }
            }
        }
    }
}

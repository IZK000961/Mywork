﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api
{
    public static class ApiHelper
    {
        public static IActionResult CreateErrorResponse(ControllerBase controller, string message)
        {
            var result = new
            {
                Status = 0,
                Message = message,
                Data = new { }
            };
            return controller.Ok(result);
        }

        public static IActionResult CreateSuccessResponse<TEntity>(ControllerBase controller, List<TEntity> data)
        {
            var message = data.Count > 0 ? "" : "No record(s) found";
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
                Data = data
            });
        }

        public static IActionResult CreateSuccessResponse<TEntity>(ControllerBase controller, TEntity data)
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = "",
                Data = data
            });
        }
        public static IActionResult CreateSuccessResponse<TEntity>(ControllerBase controller, TEntity data, string message, int status)
        {
            return controller.Ok(new
            {
                Status = status,
                Message = message,
                Data = data
            });
        }
        public static IActionResult CreateSuccessResponse(ControllerBase controller, string message)
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
                Data = new { }
            });
        }
        public static IActionResult UpdateSuccessResponse(ControllerBase controller, string message)
        {
            return controller.Ok(new
            {
                Status = 1,
                Message = message,
            });
        }
        public static void ValidateModelState(ModelStateDictionary modelState)
        {
            if (!modelState.IsValid)
            {
                var error = modelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                throw new ApplicationException(error);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using Newtonsoft.Json.Linq;
using sqy.consumer.api.DTO;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;

namespace sqy.consumer.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ConsumerController : ControllerBase
    {
        private readonly AppSettingsMongoDb _context;
        public ConsumerController(IOptions<AppSettingsMongoDb> AppSettingsMongoDb)
        {
            _context = AppSettingsMongoDb.Value;
        }
        private IMongoDatabase mongoDatabase;
        //Generic method to get the mongodb database details  
        public IMongoDatabase GetMongoDatabase()
        {
            var mongoClient = new MongoClient(_context.MongoConnection);
            return mongoClient.GetDatabase(_context.MongoDatabase);
        }


        [HttpGet, Route("GetProfile")]
        public IActionResult GetProfile()
        {
            try
            {
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                //fetch the details from CustomerDB and pass into view  
                //var result = mongoDatabase.GetCollection<Profile>("Profile").Find(FilterDefinition<Profile>.Empty).ToList();
                var result = mongoDatabase.GetCollection<Consumer>("consumer").Find(FilterDefinition<Consumer>.Empty).ToList();
                //return View(result);
                return ApiHelper.CreateSuccessResponse(this, result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet, Route("GetProfilebyLeadId")]
        public IActionResult ProfilebyLeadId(int? lead_Id)
        {
            try
            {
                if (lead_Id == null)
                {
                    return NotFound();
                }
                mongoDatabase = GetMongoDatabase();
                var collection = mongoDatabase.GetCollection<BsonDocument>("ConsumerPwa");
                var filter = Builders<BsonDocument>.Filter.Eq("consumerProfile.lead.lead_id", lead_Id);
                var result = collection.Find(filter).ToList();
                //var result1 = Newtonsoft.Json.JsonConvert.DeserializeObject(result);
                //var result1 = result[0].interests.OrderByDescending(y => y.date_added).ToList();
                //result = result.;
                //var afterorde = result.OrderBy(x=>x.interests.OrderByDescending(y=>y.date_added)).ToList();
                return ApiHelper.CreateSuccessResponse(this, result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost, Route("CreateProfile")]
        public IActionResult InsertConsumer([FromBody] BsonDocument content)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BsonDocument bdoc = new BsonDocument();
                    bdoc = MongoDB.Bson.Serialization.BsonSerializer.Deserialize<BsonDocument>(Newtonsoft.Json.JsonConvert.SerializeObject(content));

                    //var abc = JObject.Parse(content.consumerProfile.ToString());
                    //if(abc.Count>0)
                    //{
                    //    //for(int i=0;i<abc.Count;i++)
                    //    //{
                    //    //    //document.Add(abc[i].Value.ToString(), abc[i].Value);
                    //    //}
                    //}
                    //Get the database connection  
                    mongoDatabase = GetMongoDatabase();
                    //var aa = Newtonsoft.Json.JsonConvert.SerializeObject(content);
                    // var xx = Newtonsoft.Json.JsonConvert.SerializeObject(content.consumerProfile);
                    mongoDatabase.GetCollection<BsonDocument>("ConsumerPwa").InsertOne(bdoc);


                    return ApiHelper.CreateSuccessResponse(this, "consumer Added");
                   
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }

        }

        [HttpPost, Route("UpdateProfile")]
        public IActionResult UpdateConsumer([FromBody]ConsumerDTO req)
        {
            try
            {
                req.profileStatus = updateprofilestatus(req);
                if (req.lead_Id == 0)
                    return ApiHelper.CreateErrorResponse(this, "Lead_Id Required");
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                //Build the where condition  
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_id", req.lead_Id);
                //Build the update statement   
                //Consumer getdetails = mongoDatabase.GetCollection<Consumer>("consumer").Find<Consumer>(k => k.id == req.id).FirstOrDefault();
                var getdetails = collection.Find(filter).ToList();
                if (getdetails.Count > 0)
                {
                    var updatestatement = Builders<Consumer>.Update.Set("id", getdetails[0].id);
                    updatestatement = updatestatement.Set("name", req.name ?? getdetails[0].name);
                    updatestatement = updatestatement.Set("email", req.email ?? getdetails[0].email);
                    updatestatement = updatestatement.Set("country_code", req.country_code ?? getdetails[0].country_code);
                    updatestatement = updatestatement.Set("mobile", req.mobile ?? getdetails[0].mobile);
                    updatestatement = updatestatement.Set("client_city", req.client_city ?? getdetails[0].client_city);
                    updatestatement = updatestatement.Set("pincode", req.pincode ?? getdetails[0].pincode);
                    //updatestatement = updatestatement.Set("ProfileStatus", req.ProfileStatus ?? getdetails[0].ProfileStatus);
                    //updatestatement = updatestatement.Set("downpayment", req.downpayment ?? getdetails[0].downpayment);
                    updatestatement = updatestatement.Set("dob", req.dob ?? getdetails[0].dob);
                    //updatestatement = updatestatement.Set("ProfileStatus", req.ProfileStatus);
                    if (req.languages != null)
                    {

                        updatestatement = updatestatement.Set("languages", req.languages);
                    }
                    if (req.education != null)
                    {

                        updatestatement = updatestatement.Set("education", req.education);
                    }

                    if (req.salutation != null)
                    {
                        updatestatement = updatestatement.Set("salutation", req.salutation);
                    }
                    if (req.investmentDetails != null)
                    {
                        updatestatement = updatestatement.Set("investmentDetails", req.investmentDetails);
                    }
                    if (req.incomeDetails != null)
                    {
                        updatestatement = updatestatement.Set("incomeDetails", req.incomeDetails);
                    }

                    if (req.occupation != null)
                    {

                        updatestatement = updatestatement.Set("occupation", req.occupation);
                    }
                    if (req.PrefferedLocations != null)
                    {
                        // -----------Country Update----------------
                        if (req.PrefferedLocations.country != null)
                        {
                        }
                        else
                        {
                            var country = new DTO.country()
                            {
                                country_id = getdetails[0].PrefferedLocations.country.country_id,
                                text = getdetails[0].PrefferedLocations.country.text

                            };
                            req.PrefferedLocations.country = country;
                        }
                        // -----------City Update----------------
                        if (req.PrefferedLocations.city != null)
                        {
                        }
                        else
                        {
                            var city = new DTO.city()
                            {
                                city_id = getdetails[0].PrefferedLocations.city.city_id,
                                text = getdetails[0].PrefferedLocations.country.text

                            };
                            req.PrefferedLocations.city = city;
                        }
                        updatestatement = updatestatement.Set("PrefferedLocations", req.PrefferedLocations);
                    }
                    if (req.purchaseIntent != null)
                    {
                        // -----------Intents Update----------------
                        if (req.purchaseIntent.intentType != null)
                        {
                        }
                        else
                        {
                            var intenttype = new DTO.intentType()
                            {
                                intentType_id = getdetails[0].purchaseIntent.intentType.intentType_id,
                                value = getdetails[0].purchaseIntent.intentType.value

                            };
                            req.purchaseIntent.intentType = intenttype;
                        }
                        updatestatement = updatestatement.Set("purchaseIntent", req.purchaseIntent);
                    }
                    //updatestatement = updatestatement.Set("ProfileStatus", req.ProfileStatus);
                    var result = mongoDatabase.GetCollection<Consumer>("consumer").UpdateOne(filter, updatestatement);
                    if (result.IsAcknowledged == false)
                    {
                        return BadRequest("Unable to update Customer  " + getdetails[0].name);
                    }
                    else
                    {
                        var ProfileStatus = new
                        {
                            ProfileStatus = req.profileStatus,
                        };
                        return ApiHelper.CreateSuccessResponse(this, ProfileStatus, "Customer Update SuccessFully", 1);
                    }
                }
                else
                {
                    return ApiHelper.CreateErrorResponse(this, "No records found");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }


        }


        private int ProfileStatusCount(Consumer req)
        {
            try
            {
                int totalstatus = 0;

                if (req.name != null)
                { totalstatus = 10; }
                if (req.salutation != null)
                { totalstatus = totalstatus + 5; }
                if (req.dob != null)
                { totalstatus = totalstatus + 10; }
                if (req.pincode != null)
                { totalstatus = totalstatus + 10; }
                if (req.languages != null)
                { totalstatus = totalstatus + 5; }
                if (req.investmentDetails != null)
                {
                    if (req.investmentDetails.downpayment != 0)
                    { totalstatus = totalstatus + 10; }
                    if (req.investmentDetails.investment != null)
                    { totalstatus = totalstatus + 5; }
                }

                if (req.PrefferedLocations != null)
                {
                    if (req.PrefferedLocations.city != null)
                    { totalstatus = totalstatus + 5; }
                    if (req.PrefferedLocations.locations != null)
                    { totalstatus = totalstatus + 5; }
                }

                if (req.purchaseIntent != null)
                {
                    if (req.purchaseIntent.intents != null)
                    { totalstatus = totalstatus + 5; }
                    if (req.purchaseIntent.intentType != null)
                    { totalstatus = totalstatus + 5; }
                }

                if (req.occupation != null)
                {
                    if (req.occupation.employment != null)
                    { totalstatus = totalstatus + 10; }
                    if (req.occupation.designation != null)
                    { totalstatus = totalstatus + 5; }
                    if (req.occupation.company != null)
                    { totalstatus = totalstatus + 10; }
                }
                return totalstatus;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private int updateprofilestatus(ConsumerDTO req)
        {
            int totalstatus = 0;
            mongoDatabase = GetMongoDatabase();

            var collection = mongoDatabase.GetCollection<Consumer>("consumer");
            var filter = Builders<Consumer>.Filter.Eq("lead.lead_id", req.lead_Id);
            var getdetails = collection.Find(filter).ToList();
            try
            {
                totalstatus = req.name != null ? 10 : string.IsNullOrEmpty(getdetails[0].name) != true ? 10 : 0;
                totalstatus = totalstatus + Convert.ToInt32(req.salutation != null ? 5 : string.IsNullOrEmpty(getdetails[0].salutation.value) != true ? 5 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.dob != null ? 10 : string.IsNullOrEmpty(getdetails[0].dob) != true ? 10 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.pincode != null ? 10 : getdetails[0].salutation.value != null ? 10 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.languages != null ? 5 : getdetails[0].languages != null ? 5 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.investmentDetails != null ? req.investmentDetails.downpayment != 0 ? 10 : getdetails[0].investmentDetails.downpayment != 0 ? 10 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.investmentDetails != null ? req.investmentDetails.investment != null ? 5 : getdetails[0].investmentDetails.investment != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.PrefferedLocations != null ? req.PrefferedLocations.city != null ? 5 : getdetails[0].PrefferedLocations.city != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.PrefferedLocations != null ? req.PrefferedLocations.locations != null ? 5 : getdetails[0].PrefferedLocations.locations != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.purchaseIntent != null ? req.purchaseIntent.intents != null ? 5 : getdetails[0].purchaseIntent.intents != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.purchaseIntent != null ? req.purchaseIntent.intentType != null ? 5 : getdetails[0].purchaseIntent.intentType != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.employment != null ? 10 : getdetails[0].occupation.employment != null ? 10 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.designation != null ? 5 : getdetails[0].occupation.designation != null ? 5 : 0 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.company != null ? 10 : getdetails[0].occupation.company != null ? 10 : 0 : 0);




                return totalstatus;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
    }
}
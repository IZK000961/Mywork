﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using sqy.consumer.api.DTO;
using sqy.consumer.api.Middleware;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ProfileController : ControllerBase
    {
        private readonly AppSettingsMongoDb _context;
        public ProfileController(IOptions<AppSettingsMongoDb> AppSettingsMongoDb)
        {
            _context = AppSettingsMongoDb.Value;
        }
        private IMongoDatabase mongoDatabase;
        //Generic method to get the mongodb database details  
        public IMongoDatabase GetMongoDatabase()
        {
            var mongoClient = new MongoClient(_context.MongoConnection);
            return mongoClient.GetDatabase(_context.MongoDatabase);
        }
        [HttpGet, Route("GetProfile")]
        public IActionResult GetProfile()
        {
            try
            {
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                //fetch the details from CustomerDB and pass into view  
                //var result = mongoDatabase.GetCollection<Profile>("Profile").Find(FilterDefinition<Profile>.Empty).ToList();
                var result = mongoDatabase.GetCollection<Consumer>("consumer").Find(FilterDefinition<Consumer>.Empty).ToList();
                //return View(result);
                return ApiHelper.CreateSuccessResponse(this, result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet, Route("GetProfilebyLeadId")]
        public IActionResult ProfilebyLeadId(string lead_id)
        {
            try
            {
                if (lead_id == null)
                {
                    return NotFound();
                }
                mongoDatabase = GetMongoDatabase();
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", lead_id.ToString());
                var result = collection.Find(filter).ToList();
                if (result.Count > 0)
                {
                    //var FirstConsumerDate = result[0].FirstConsumeDate;

                    //if (result[0].FirstConsumeDate == Convert.ToDateTime("01-01-0001 00:00:00"))
                    //{
                    //    var updatestatement = Builders<Consumer>.Update.Set("id", result[0].id);
                    //    updatestatement = updatestatement.Set("FirstConsumeDate", DateTime.Now);
                    //    var updateFirstConsumeDate = mongoDatabase.GetCollection<Consumer>("consumer").UpdateOne(filter, updatestatement);
                    //    result[0].FirstConsumeDate = DateTime.Now;
                    //}
                }
                return ApiHelper.CreateSuccessResponse(this, result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost, Route("CreateProfile")]
        public IActionResult InsertConsumer([FromBody] Consumer req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    req.profileStatus = ProfileStatusCount(req);

                    if (Convert.ToInt32(req.lead[0].segment)==7)
                    {                                                
                            req.PrefferedLocations = new DataEntities.PrefferedLocations();
                            req.PrefferedLocations.country = new DataEntities.country();
                            req.PrefferedLocations.country.country_id = 1;
                            req.PrefferedLocations.country.text = "India";
                        
                    }
                    else if(Convert.ToInt32(req.lead[0].segment) == 8)
                    {
                        req.PrefferedLocations = new DataEntities.PrefferedLocations();
                        req.PrefferedLocations.country = new DataEntities.country();
                        if (Convert.ToInt32(req.country_code)!=1)
                        {
                            
                            req.PrefferedLocations.country.text = "UAE";
                            req.PrefferedLocations.country.country_id = 2;
                        }
                        if (Convert.ToInt32(req.country_code) == 1)
                        {
                            req.PrefferedLocations.country.text = "Canada";
                            req.PrefferedLocations.country.country_id = 3;
                        }
                    }
                    //Get the database connection  
                    mongoDatabase = GetMongoDatabase();
                    //var result = mongoDatabase.GetCollection<Consumer>("consumer").Find<Consumer>(k => k.mobile == req.mobile).ToList();
                    var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                    var filter = Builders<Consumer>.Filter.Eq("mobile", req.mobile);
                    var result = collection.Find(filter).ToList();
                    if (result.Count > 0) {
                        var result1 = result[0].lead.Find(k => k.segment == req.lead[0].segment);
                        
                        if (result1!=null)
                        {
                            return ApiHelper.CreateErrorResponse(this, "Consumer already found");
                        }
                        else
                        {
                            var newLead = new lead()
                            {
                                lead_id = req.lead[0].lead_id,
                                lead_hash = req.lead[0].lead_hash,
                                segment = req.lead[0].segment,
                            };
                            var updater = Builders<Consumer>.Update.AddToSet("lead", newLead);
                            collection.UpdateOne(filter, updater);
                            return ApiHelper.CreateSuccessResponse(this, "Lead Added");
                        }
                    }
                    else
                    {
                        mongoDatabase.GetCollection<Consumer>("consumer").InsertOne(req);
                        return ApiHelper.CreateSuccessResponse(this, "consumer Added");
                    }
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }

        }

        [HttpPost, Route("AddLead")]
        public IActionResult AddLead([FromBody]AddleadDTO req)
        {
            try
            {
                if (req.mobile == null)
                    return ApiHelper.CreateErrorResponse(this, "Lead_Id Required");
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                //Build the where condition  
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("mobile", req.mobile);
                //Build the update statement   
                //Consumer getdetails = mongoDatabase.GetCollection<Consumer>("consumer").Find<Consumer>(k => k.id == req.id).FirstOrDefault();
                var getdetails = collection.Find(filter).ToList();
                if (getdetails.Count > 0)
                {
                    var updatestatement = Builders<Consumer>.Update.Set("id", getdetails[0].id);
                    if (req.lead != null)
                    {
                        // -----------Intents Update----------------

                        updatestatement = updatestatement.Set("lead", req.lead);
                    }
                    var result = mongoDatabase.GetCollection<Consumer>("consumer").UpdateOne(filter, updatestatement);
                    if (result.IsAcknowledged == false)
                    {
                        return BadRequest("Unable to update Customer  " + getdetails[0].name);
                    }
                    else
                    {
                        return ApiHelper.CreateSuccessResponse(this, "Customer Update SuccessFully");
                    }
                }
                else
                {
                    return ApiHelper.CreateErrorResponse(this, "No records found");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }


        [HttpPost, Route("UpdateProfile")]
        public IActionResult UpdateConsumer([FromBody]ConsumerDTO req)
        {
            try
            {
                req.profileStatus = updateprofilestatus(req);
                req.lead_hash = req.lead_Id.ToString();
                if (req.lead_hash == null)
                    return ApiHelper.CreateErrorResponse(this, "Lead_Id Required");
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                //Build the where condition  
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", req.lead_hash);
                //Build the update statement   
                //Consumer getdetails = mongoDatabase.GetCollection<Consumer>("consumer").Find<Consumer>(k => k.id == req.id).FirstOrDefault();
                var getdetails = collection.Find(filter).ToList();
                if (getdetails.Count > 0)
                {
                    var updatestatement = Builders<Consumer>.Update.Set("id", getdetails[0].id);
                    updatestatement = updatestatement.Set("name", req.name ?? getdetails[0].name);
                    updatestatement = updatestatement.Set("email", req.email ?? getdetails[0].email);
                    updatestatement = updatestatement.Set("country_code", req.country_code ?? getdetails[0].country_code);
                    updatestatement = updatestatement.Set("mobile", req.mobile ?? getdetails[0].mobile);
                    updatestatement = updatestatement.Set("client_city", req.client_city ?? getdetails[0].client_city);
                    updatestatement = updatestatement.Set("client_country", req.client_country ?? getdetails[0].client_country);
                    updatestatement = updatestatement.Set("pincode", req.pincode ?? getdetails[0].pincode);
                    //updatestatement = updatestatement.Set("ProfileStatus", req.ProfileStatus ?? getdetails[0].ProfileStatus);
                    //updatestatement = updatestatement.Set("anniversary_date", Convert.ToDateTime(req.anniversary_date ?? getdetails[0].anniversary_date));
                    updatestatement = updatestatement.Set("dob", req.dob ?? getdetails[0].dob);
                    updatestatement = updatestatement.Set("profileStatus", req.profileStatus);
                    //updatestatement = updatestatement.Set("updated_on", DateTime.Now);
                    if (req.updatedBy != 0)
                    {
                        if (req.updatedBy != -1)
                        {
                            updatestatement = updatestatement.Set("agentUpdated_on", DateTime.Now);
                            updatestatement = updatestatement.Set("updatedBy", req.updatedBy);

                        }
                        else
                        {
                            updatestatement = updatestatement.Set("updated_on", DateTime.Now);
                            //updatestatement = updatestatement.Set("updatedBy", req.updatedBy);
                        }
                    }
                    

                    if (req.firstJourney != Convert.ToDateTime("01-01-0001 00:00:00"))
                    {
                        updatestatement = updatestatement.Set("firstJourney", req.firstJourney);
                    }
                    if (req.anniversary_date != null)
                    {
                        updatestatement = updatestatement.Set("anniversary_date", req.anniversary_date);
                    }
                    if (req.languages != null)
                    {

                        updatestatement = updatestatement.Set("languages", req.languages);
                    }
                    if (req.education != null)
                    {

                        updatestatement = updatestatement.Set("education", req.education);
                    }

                    if (req.salutation != null)
                    {
                        updatestatement = updatestatement.Set("salutation", req.salutation);
                    }
                    if (req.CreditScore != null)
                    {
                        updatestatement = updatestatement.Set("CreditScore", req.CreditScore);
                    }
                    
                    if (req.investmentDetails != null)
                    {
                        updatestatement = updatestatement.Set("investmentDetails", req.investmentDetails);
                    }
                    if (req.incomeDetails != null)
                    {
                        updatestatement = updatestatement.Set("incomeDetails", req.incomeDetails);
                    }

                    if (req.occupation != null)
                    {

                        updatestatement = updatestatement.Set("occupation", req.occupation);
                    }
                    if (req.PrefferedLocations != null)
                    {
                        updatestatement = updatestatement.Set("PrefferedLocations", req.PrefferedLocations);
                    }
                    if (req.purchaseIntent != null)
                    {
                        // -----------Intents Update----------------
                        if (req.purchaseIntent.intentType != null)
                        {
                        }
                        else
                        {
                            var intenttype = new DTO.intentType()
                            {
                                intentType_id = getdetails[0].purchaseIntent.intentType.intentType_id,
                                value = getdetails[0].purchaseIntent.intentType.value

                            };
                            req.purchaseIntent.intentType = intenttype;
                        }
                        updatestatement = updatestatement.Set("purchaseIntent", req.purchaseIntent);
                    }
                    var result = mongoDatabase.GetCollection<Consumer>("consumer").UpdateOne(filter, updatestatement);
                    if (result.IsAcknowledged == false)
                    {
                        return BadRequest("Unable to update Customer  " + getdetails[0].name);
                    }
                    else
                    {
                        var ProfileStatus = new
                        {
                            profileStatus= req.profileStatus,
                            pageStatus = getdetails[0].PageStatus
                        };
                        return ApiHelper.CreateSuccessResponse(this, ProfileStatus, "Customer Update SuccessFully", 1);
                    }
                }
                else
                {
                    return ApiHelper.CreateErrorResponse(this, "No records found");
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }


        }


        private int ProfileStatusCount(Consumer req)
        {
            try
            {
                var statuslist = new PageStatus();
                int totalstatus = 0;
                #region Personal_Info
                if (req.name != null)
                { totalstatus = 10;
                    statuslist.PersonalInfo = 29;
                }
                if (req.salutation != null)
                { totalstatus = totalstatus + 5;
                    statuslist.PersonalInfo = statuslist.PersonalInfo + 14;
                }
                if (req.dob != null)
                { totalstatus = totalstatus + 5;
                    statuslist.PersonalInfo = statuslist.PersonalInfo + 14;
                }
                if (req.pincode != null)
                { totalstatus = totalstatus + 10;
                    statuslist.PersonalInfo = statuslist.PersonalInfo + 29;
                }
                if (req.anniversary_date != null)
                { totalstatus = totalstatus + 0;
                    statuslist.PersonalInfo = statuslist.PersonalInfo + 0;
                }
                if (req.languages != null)
                { totalstatus = totalstatus + 5;
                    statuslist.PersonalInfo = statuslist.PersonalInfo + 14;
                }
                #endregion

                #region Property
                if (req.investmentDetails != null)
                {
                    if (req.investmentDetails.downpayment != 0)
                    { totalstatus = totalstatus + 5;
                        statuslist.Property = statuslist.Property + 40;
                    }
                    if (req.investmentDetails.investment != null)
                    { totalstatus = totalstatus + 10;
                        statuslist.Property = statuslist.Property + 20;
                    }
                }
                if (req.purchaseIntent != null)
                {
                    if (req.purchaseIntent.intents != null)
                    { totalstatus = totalstatus + 5;
                        statuslist.Property = statuslist.Property + 20;
                    }
                    if (req.purchaseIntent.intentType != null)
                    { totalstatus = totalstatus + 5;
                        statuslist.Property = statuslist.Property + 20;
                    }
                }
                #endregion

                #region Location
                if (req.PrefferedLocations != null)
                {
                    if (req.PrefferedLocations.city != null)
                    { totalstatus = totalstatus + 5;
                        statuslist.Location = statuslist.Location + 50;
                    }
                    if (req.PrefferedLocations.locations != null)
                    { totalstatus = totalstatus + 5;
                        statuslist.Location = statuslist.Location + 50;
                    }
                }
                #endregion

                #region Employment
                if (req.occupation != null)
                {
                    if (req.occupation.employment != null)
                    {
                        totalstatus = totalstatus + 10;
                        if (req.occupation.employment.employment_id == 1)
                        {
                            if (req.occupation.designation != null)
                            { totalstatus = totalstatus + 5;
                                statuslist.Employment = statuslist.Employment + 33;
                                    }
                            if (req.occupation.company != null)
                            { totalstatus = totalstatus + 10;
                                statuslist.Employment = statuslist.Employment + 17;
                            }
                        }
                        else if (req.occupation.employment.employment_id == 2)
                        {
                            if (req.occupation.businessNature != null)
                            { totalstatus = totalstatus + 5;
                                statuslist.Employment = statuslist.Employment + 33;
                            }
                            if (req.occupation.businessName != null)
                            { totalstatus = totalstatus + 10;
                                statuslist.Employment = statuslist.Employment + 17;
                            }
                        }
                        else if (req.occupation.employment.employment_id == 3)
                        {
                            if (req.occupation.professionType != null)
                            { totalstatus = totalstatus + 15;
                                statuslist.Employment = statuslist.Employment + 50;
                            }
                        }
                    }
                }
                if (req.incomeDetails != null)
                {
                    if (req.incomeDetails.income != null)
                    { totalstatus = totalstatus + 5;
                        statuslist.Employment = statuslist.Employment + 17;
                    }
                }
                #endregion

                //statuslist.Personal_Info = statuslist.Personal_Info;
                //statuslist.Property = req.Property;
                //statuslist.Location = req.Location;
                //statuslist.Employment = req.Employment;
                //statuslist.profileStatus = totalstatus;
                return totalstatus;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        private int updateprofilestatus(ConsumerDTO req)
        {
            int totalstatus = 0;
            mongoDatabase = GetMongoDatabase();
            req.lead_hash = req.lead_Id.ToString();
            var collection = mongoDatabase.GetCollection<Consumer>("consumer");
            var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", req.lead_hash);
            var getdetails = collection.Find(filter).ToList();
            try
            {
                totalstatus = req.name != null ? 10 : string.IsNullOrEmpty(getdetails[0].name) != true ? 10 : 0;
                #region salutation
                if (req.salutation != null)
                {
                    totalstatus = totalstatus + 5;
                }
                else if(getdetails[0].salutation!=null)
                {
                    totalstatus = totalstatus + 5;
                }
                #endregion 

                //totalstatus = totalstatus + Convert.ToInt32(req.salutation != null ? 5 : string.IsNullOrEmpty(getdetails[0].salutation.value) != true ? 5 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.dob != null ? 5 : string.IsNullOrEmpty(getdetails[0].dob) != true ? 5 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.pincode != null ? 10 : getdetails[0].pincode != null ? 10 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.languages != null ? 5 : getdetails[0].languages != null ? 5 : 0);
                totalstatus = totalstatus + Convert.ToInt32(req.anniversary_date != null ? 0 : getdetails[0].anniversary_date != null ? 0 : 0);
                if (req.PrefferedLocations != null)
                {
                    if(req.PrefferedLocations.city != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                    if (req.PrefferedLocations.locations != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                }
                else if (getdetails[0].PrefferedLocations != null)
                {
                    if (getdetails[0].PrefferedLocations.city != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                    if (getdetails[0].PrefferedLocations.locations != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                }

                if (req.purchaseIntent != null)
                {
                    if (req.purchaseIntent.intents.Count>0)
                    {
                        totalstatus = totalstatus + 5;
                    }
                    if (req.purchaseIntent.intentType != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                }
                else if (getdetails[0].purchaseIntent != null)
                {
                    if (getdetails[0].purchaseIntent.intents != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                    if (getdetails[0].purchaseIntent.intentType != null)
                    {
                        totalstatus = totalstatus + 5;
                    }
                }

                if (req.occupation != null)
                {
                    if (req.occupation.employment != null)
                    {
                        if (req.occupation.employment.employment_id == 1)
                        {
                            totalstatus = totalstatus + 10;
                            if (req.occupation.designation != null)
                            { totalstatus = totalstatus + 5; }
                            if (req.occupation.company != null)
                            { totalstatus = totalstatus + 10; }
                        }
                        else if (req.occupation.employment.employment_id == 2)
                        {
                            totalstatus = totalstatus + 10;
                            if (req.occupation.businessNature != null)
                            { totalstatus = totalstatus + 5; }
                            if (req.occupation.businessName != null)
                            { totalstatus = totalstatus + 10; }
                        }
                        else if (req.occupation.employment.employment_id == 3)
                        {
                            totalstatus = totalstatus + 10;
                            if (req.occupation.professionType != null)
                            { totalstatus = totalstatus + 15; }
                        }
                        else if (req.incomeDetails.income !=null)
                        {
                            totalstatus = totalstatus + 5;
                        }
                    }
                }
                else if (getdetails[0].occupation != null)
                {
                    if (getdetails[0].occupation.employment != null)
                    {
                        if (getdetails[0].occupation.employment.employment_id == 1)
                        {
                            totalstatus = totalstatus + 10;
                            if (getdetails[0].occupation.designation != null)
                            { totalstatus = totalstatus + 5; }
                            if (getdetails[0].occupation.company != null)
                            { totalstatus = totalstatus + 10; }
                        }
                        else if (getdetails[0].occupation.employment.employment_id == 2)
                        {
                            totalstatus = totalstatus + 10;
                            if (getdetails[0].occupation.businessNature != null)
                            { totalstatus = totalstatus + 5; }
                            if (getdetails[0].occupation.businessName != null)
                            { totalstatus = totalstatus + 10; }
                        }
                        else if (getdetails[0].occupation.employment.employment_id == 3)
                        {
                            totalstatus = totalstatus + 10;
                            if (getdetails[0].occupation.professionType != null)
                            { totalstatus = totalstatus + 15; }
                        }
                        else if (getdetails[0].incomeDetails.income != null)
                        {
                            totalstatus = totalstatus + 5;
                        }
                    }


                }

                if(req.investmentDetails!=null)
                {
                    if(req.investmentDetails.investment!=null)
                        totalstatus = totalstatus + 10;
                    if (req.investmentDetails.downpayment != 0)
                        totalstatus = totalstatus + 5;
                }
                else if (getdetails[0].investmentDetails != null)
                {
                    if (getdetails[0].investmentDetails.investment != null)
                        totalstatus = totalstatus + 10;
                    if (getdetails[0].investmentDetails.downpayment != 0)
                        totalstatus = totalstatus + 5;
                }

                if(req.incomeDetails!=null)
                {
                    totalstatus = totalstatus + 5;
                }
                else if(getdetails[0].incomeDetails!=null)
                { totalstatus = totalstatus + 5; }
                //totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.employment != null ? 10 : getdetails[0].occupation.employment != null ? 10 : 0 : 0);
                //totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.designation != null ? 5 : getdetails[0].occupation.designation != null ? 5 : 0 : 0);
                //totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.occupation.company != null ? 10 : getdetails[0].occupation.company != null ? 10 : 0 : 0);
                //totalstatus = totalstatus + Convert.ToInt32(req.occupation != null ? req.incomeDetails.income != null ? 5 : getdetails[0].incomeDetails.income != null ? 5 : 0 : 0);




                return totalstatus;
            }
            catch (Exception ex)
            {
                throw;
            }

        }
        private statusprofile profilescreen(string lead_Id)
        {
            var statusprofile = new statusprofile();
           // int Personal_Info = 0;
           // int Property = 0;
            mongoDatabase = GetMongoDatabase();

            var collection = mongoDatabase.GetCollection<Consumer>("consumer");
            var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", lead_Id);
            var getdetails = collection.Find(filter).ToList();

            if (getdetails[0].name != null)
            {
                statusprofile.Personal_Info = 10;
            }
            if (getdetails[0].salutation != null)
            {
                statusprofile.Personal_Info = statusprofile.Personal_Info + 5;
            }
            if (getdetails[0].dob != null)
            {
                statusprofile.Personal_Info = statusprofile.Personal_Info + 5;
            }
            if (getdetails[0].pincode != null)
            {
                statusprofile.Personal_Info = statusprofile.Personal_Info + 10;
            }
            if (getdetails[0].languages != null)
            {
                statusprofile.Personal_Info = statusprofile.Personal_Info + 5;
            }



            if (getdetails[0].investmentDetails.downpayment != null)
            {
                statusprofile.Property = 10;
            }
            if (getdetails[0].investmentDetails.investment != null)
            {
                statusprofile.Property = statusprofile.Property + 5;
            }
            if (getdetails[0].investmentDetails.investment != null)
            {
                statusprofile.Property = statusprofile.Property + 5;
            }
            if (getdetails[0].purchaseIntent.intents != null)
            {
                statusprofile.Property = statusprofile.Property + 5;
            }
            if (getdetails[0].purchaseIntent.intents != null)
            {
                statusprofile.Property = statusprofile.Property + 5;
            }
            return statusprofile;
        }

    }
    public class statusprofile
    {
        public int Personal_Info { get; set; } = 0;
        public int Property { get; set; } = 0;
        public int Location { get; set; } = 0;
        public int Employment { get; set; } = 0;
        public int profileStatus { get; set; } = 0;
    }
}
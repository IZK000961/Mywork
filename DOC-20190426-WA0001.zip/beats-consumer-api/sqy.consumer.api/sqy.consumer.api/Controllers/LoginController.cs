﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using sqy.consumer.DataEntities;
using sqy.consumer.DataAccess;
using sqy.consumer.api.DTO;
using System.Data;
using sqy.consumer.Helper;
using System.Web;
using System.Net.Http;
using System.Net.Http.Headers;
using sqy.consumer.api.Middleware;
using Microsoft.Extensions.Primitives;
//using Microsoft.Extensions.Logging;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        //private readonly ILogger<LoginController> _logger;
        public LoginController(IHttpContextAccessor httpContextAccessor)//,ILogger<LoginController> logger)
        {
            _httpContextAccessor = httpContextAccessor;
            //_logger = logger;
        }

        HttpClient client = new HttpClient();
        [HttpPost]
        public IActionResult Post([FromBody] LoginRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DAConsumerLogin da = new DAConsumerLogin();
                    DEConsumerLogin de = new DEConsumerLogin()
                    {
                        CallValue = DEConsumerLoginCallValues.GenrateOTP,
                        PhoneNumber = req.PhoneNumber,
                        CountryCode = req.CountryCode,
                        SegmentId = req.SegmentId,
                        //RequestId = req.RequestId
                    };

                    var ds = da.Execute(de);
                    var data = ds.Tables[0];
                    /* sendsms(data.Rows[0]["CountryCode"].ToString(),
                            data.Rows[0]["PhoneNumber"].ToString(),
                            data.Rows[0]["OTP"].ToString(),
                            Convert.ToInt32(data.Rows[0]["TriedCount"])); */
                    if (ds == null)
                    {
                        throw new ApplicationException("Invalid PhoneNumber");
                    }

                   
                    
                    return ApiHelper.CreateSuccessResponse(this, data);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost,Route("resendotp")]
        public IActionResult ResendOTP([FromBody] LoginRequestDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    DAConsumerLogin da = new DAConsumerLogin();
                    DEConsumerLogin de = new DEConsumerLogin()
                    {
                        CallValue = DEConsumerLoginCallValues.resendotp,
                        RequestId = req.RequestId
                    };

                    var ds = da.Execute(de);
                    var data = ds.Tables[0];
                    /* sendsms(data.Rows[0]["CountryCode"].ToString(),
                            data.Rows[0]["PhoneNumber"].ToString(),
                            data.Rows[0]["OTP"].ToString(),
                            Convert.ToInt32(data.Rows[0]["TriedCount"])); */
                    if (ds == null)
                    {
                        throw new ApplicationException("Invalid PhoneNumber");
                    }



                    return ApiHelper.CreateSuccessResponse(this, data);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0].ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetCountry")]
        public IActionResult GetCountry()
        {
            var http = _httpContextAccessor.HttpContext.Request.Headers["HeaderOrigin"].ToString();
            StringValues originValues;
            var siteadd = Request.Headers.TryGetValue("HeaderOrigin", out originValues);
            //_logger.LogInformation("HeaderOrigin: " + siteadd);
            DataTable dt = new DataTable();
            try
            {
                DAConsumerLogin da = new DAConsumerLogin();
                DEConsumerLogin de = new DEConsumerLogin()
                {
                    CallValue = DEConsumerLoginCallValues.GetLocation,
                };

                var ds = da.Execute(de);

                var FilterRes = ds.Tables[0];

                return ApiHelper.CreateSuccessResponse(this, FilterRes);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost]
        [Route("VerifyOTP")]
        public IActionResult VerifyOTP([FromBody] LoginOTPDTO req)
        {

            try
            {
                
                if (ModelState.IsValid)
                {
                    StringValues originValues;
                    var siteadd = Request.Headers.TryGetValue("HeaderOrigin", out originValues);
                    DAConsumerLogin da = new DAConsumerLogin();
                    DEConsumerLogin de = new DEConsumerLogin()
                    {

                        CallValue = DEConsumerLoginCallValues.ValidateOTP,
                        RequestId=req.requestId,
                        OTP = req.OTP
                    };
                    var ds = da.Execute(de);

                    var response = new
                    {
                        RequestId=ds.Tables[0].Rows[0]["RequestId"],
                        SegmentId= ds.Tables[0].Rows[0]["SegmentId"],
                        lead_hash = ds.Tables[0].Rows[0]["Leadhash"],
                        Origin= siteadd
                    };
                    CookieOptions option = new CookieOptions();
                    
                    option.Expires = DateTime.Now.AddDays(1);
                    option.Domain = ".squareyards.com";
                    option.Path = "/";
                    var token = ds.Tables[0].Rows[0]["ApiAccessToken"].ToString();
                    Request.HttpContext.Response.Cookies.Append("_users", token, option);
                    return ApiHelper.CreateSuccessResponse(this, response, "OTP Matched Succedfully", 1);
                }
                else
                {
                    var modelError = ModelState.Values.Where(v => v.Errors.Count > 0).FirstOrDefault().Errors[0];
                    var error = modelError.ErrorMessage == "" ? modelError.Exception.Message : modelError.ErrorMessage;

                    return ApiHelper.CreateErrorResponse(this, error);
                    // throw new ApplicationException(error);
                }
            }

            catch (Exception ex)
            {
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet]
        [Route("Authenticate")]
        public IActionResult verifyToken()
            {
            var token = Request.Cookies["_users"];
            if (string.IsNullOrEmpty(token))
            {
                return StatusCode(403);
            }
            //else if (token == "43245432fgwervwrw43trf45")
            //{
            //    return Ok();
            //}
            else
                return Ok();

            //return ApiHelper.CreateSuccessResponse(this, token, "Validated Succedfully",1);
        }

        private bool sendsms(string countrycode, string mobileno, string Otp, int tryCount = 1)
        {
            string smsurl = "";
            bool vflag = false;
            string msg = "";
            try
            {
                var smskey = AppSettingsConf.SMSKeySettings();
                if (smskey.Testing == 1)
                    mobileno = smskey.TestMobileNo;
                if (countrycode.Replace("+", "") == "91")
                {
                    var domesticsms = AppSettingsConf.SMSKeySettings();
                    msg = domesticsms.DomesticSMS;


                    //msg = happyOtp + " is your Square Connect Mobile App Verification Code";
                    msg = msg.Replace("{HappyOtp}", Otp);
                    // happyOtp + uHappyOtp + " If you were satisfied with your meeting with our representative please Share OTP Xxxx. For any reason if you were not satisfied please share YYYY.";
                    msg = HttpUtility.UrlEncode(msg);
                    mobileno = HttpUtility.UrlEncode(mobileno); //"919716214179"; 
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.DomesticUrl;
                    if (smsurl != null)
                    {
                        smsurl = smsurl.Replace("amp;", "").Replace("{MobileNo}", mobileno.Trim()).Replace("{Message}", msg.Trim());
                        // _logger.LogInformation("SMS URL {0}", smsurl);
                        HttpResponseMessage response = client.GetAsync(smsurl).Result;

                        var result = response.Content.ReadAsStringAsync().Result;
                        if (response.IsSuccessStatusCode)
                        {
                            if (response.StatusCode.ToString().ToLower() == "ok")
                                vflag = true;
                        }
                    }
                    else
                        vflag = false;

                }
                else if (countrycode.Replace("+", "") == "971" && tryCount == 1)
                {
                    var gccsms = AppSettingsConf.SMSKeySettings();
                    msg = gccsms.GCCMsg;

                    //msg = happyOtp + " is your Square Connect Mobile App Verification Code";
                    msg = msg.Replace("{HappyOtp}", Otp);
                    // happyOtp + uHappyOtp + " If you were satisfied with your meeting with our representative please Share OTP Xxxx. For any reason if you were not satisfied please share YYYY.";
                    msg = HttpUtility.UrlEncode(msg);
                    mobileno = HttpUtility.UrlEncode(mobileno); //"9716214179"; 
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.GCCUrl;
                    if (smsurl != null)
                    {
                        smsurl = smsurl.Replace("amp;", "")
                            .Replace("{MobileNo}", mobileno.Trim())
                            .Replace("{Message}", msg.Trim())
                            .Replace("{CountryCode}", countrycode.Replace("+", ""));
                        // _logger.LogInformation("SMS URL {0}", smsurl);
                        HttpResponseMessage response = client.GetAsync(smsurl).Result;

                        var result = response.Content.ReadAsStringAsync().Result;
                        if (response.IsSuccessStatusCode)
                        {
                            if (response.StatusCode.ToString().ToLower() == "ok")
                                vflag = true;
                        }
                    }
                    else
                        vflag = false;
                }
                else
                {
                    string number = mobileno;
                    msg = Otp;
                    msg = HttpUtility.UrlEncode(msg);
                    number = HttpUtility.UrlEncode(number);
                    var url = AppSettingsConf.SendSMSSettings(SMSType.SMS);
                    smsurl = url.GlobalUrl;
                    if (smsurl != null)
                    {
                        var Globalsms = AppSettingsConf.SMSKeySettings();
                        var GlobalHappy = Globalsms.GlobalHappysms;
                        var GlobalUnHappy = Globalsms.GlobalUnHappysms;
                        var Happyurl = smsurl.Replace("{api}", url.Apikey).Replace("{MobileNo}", number.Trim()).Replace("{otp}", Otp).Replace("{msgTemplate}", GlobalHappy);

                        var UnHappyurl = smsurl.Replace("{api}", url.Apikey).Replace("{MobileNo}", number.Trim()).Replace("{otp}", Otp).Replace("{msgTemplate}", GlobalUnHappy);

                        HttpResponseMessage Happyresponse = client.GetAsync(Happyurl).Result;

                        HttpResponseMessage unHappyresponse = client.GetAsync(UnHappyurl).Result;
                    }
                    else
                        vflag = false;
                }
            }
            catch (Exception ex)
            {
                string str = ex.Message + "Inner Exception " + ex.InnerException;
                //while (ex.InnerException != null) ex = ex.InnerException;
                //_logger.LogInformation("HTTP Inner Exception {0}", ex.Message);
            }
            return vflag;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using sqy.consumer.api.Middleware;
using sqy.consumer.api.Models;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [ApiController]
    public class TrackerController : ControllerBase
    {
        private readonly AppSettingsMongoDb _context;
        public TrackerController(IOptions<AppSettingsMongoDb> AppSettingsMongoDb)
        {
            _context = AppSettingsMongoDb.Value;
        }
        private IMongoDatabase mongoDatabase;
        //Generic method to get the mongodb database details  
        public IMongoDatabase GetMongoDatabase()
        {
            var mongoClient = new MongoClient(_context.MongoConnection);
            return mongoClient.GetDatabase(_context.MongoDatabase);
        }

        [HttpPost]
        public IActionResult post([FromBody] Tracker req)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    BsonDocument bdoc = new BsonDocument();
                    bdoc = MongoDB.Bson.Serialization.BsonSerializer.Deserialize<BsonDocument>(Newtonsoft.Json.JsonConvert.SerializeObject(req));


                    //Get the database connection  
                    mongoDatabase = GetMongoDatabase();
                    var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                    if (req.lead_hash != null)
                    {
                        var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", req.lead_hash);
                        var result = collection.Find(filter).ToList();
                        if (result.Count > 0)
                        {
                            //var FirstConsumerDate = result[0].FirstConsumeDate;

                            if (result[0].FirstConsumeDate == Convert.ToDateTime("01-01-0001 00:00:00"))
                            {
                                var updatestatement = Builders<Consumer>.Update.Set("id", result[0].id);
                                updatestatement = updatestatement.Set("FirstConsumeDate", DateTime.Now);
                                var updateFirstConsumeDate = mongoDatabase.GetCollection<Consumer>("consumer").UpdateOne(filter, updatestatement);
                            }
                        }
                    }
                    mongoDatabase.GetCollection<BsonDocument>("Tracker").InsertOne(bdoc);
                    
                    
                    return ApiHelper.CreateSuccessResponse(this, "Added");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }

        }
    }
}
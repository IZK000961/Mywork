﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using sqy.consumer.api.DTO;
using sqy.consumer.DataAccess;
using sqy.consumer.DataEntities;
using System.Globalization;
using sqy.consumer.Helper;
using Microsoft.AspNetCore.Hosting;
using System.IO;
using sqy.beatsconnect.api.Models;
using sqy.consumer.api.Middleware;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [Route("api/v2/[controller]")]
    [ApiController]
    public class RMController : ControllerBase
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        public RMController(IHostingEnvironment hostingEnvironment)
        {

            _hostingEnvironment = hostingEnvironment;
        }
        [HttpGet]
        [Route("GetRMDetails")]
        public IActionResult GetRMDetails(string Id,string Type)
        {
            DataTable dt = new DataTable();
            try
            {
                if (Id == null)
                {
                    return NotFound();
                }
                DAConsumerRM da = new DAConsumerRM();
                DEConsumerRM de = new DEConsumerRM()
                {
                    CallValue = DEConsumerRMCallValues.GetRMDetails,
                    lead_hash = Id,
                    Type= Type
                };

                var ds = da.Execute(de);

                var FilterRes = ds.Tables[0];

                return ApiHelper.CreateSuccessResponse(this, FilterRes);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost]
        [Route("ChangeRM")]
        public IActionResult ChangeRM([FromBody] RmDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    DAConsumerRM da = new DAConsumerRM();
                    DEConsumerRM de = new DEConsumerRM()
                    {
                        CallValue = DEConsumerRMCallValues.AddRMChangeRequest,
                        lead_hash = req.Lead_Id,
                        RMId = req.RMId,
                        ChangeReason = req.Reason,
                        SubReason = req.SubReason,
                        Remarks = req.Remarks,
                        //ProcessDate = DateTime.ParseExact(req.ProcessDate, "yyyy-MM-dd", CultureInfo.InvariantCulture),
                        //Updatedby = 1
                    };

                    var ds = da.Execute(de);
                    return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
                    //if (de.dsResult != null && de.dsResult.Tables[0].Rows.Count > 0)
                    //{
                    //    return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
                    //}
                    //  else
                    //    return ApiHelper.CreateSuccessResponse(this, ds.Tables[0], "Something Went Worng!",0);

                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet]
        [Route("ChangeRMReason")]
        public IActionResult ChangeRMReason()
        {
            try
            {

                var ds = RMchangereason();
                return ApiHelper.CreateSuccessResponse(this, ds);

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        public List<DEConsumerRMReasonResponse> RMchangereason()
        {
            DAConsumerRM da = new DAConsumerRM();
            DEConsumerRM de = new DEConsumerRM()
            {
                CallValue = DEConsumerRMCallValues.GetRMChangeReason
            };
            List<DEConsumerRMReasonResponse> Rmreason = new List<DEConsumerRMReasonResponse>();
            DataSet ds = da.Execute(de);
            if (ds.Tables.Count > 0)
            {
                DataTable dt = (DataTable)ds.Tables[0];
                DataTable dt2 = (DataTable)ds.Tables[1];
                //DataTable dt1 = dt.DefaultView.ToTable(true, "ReasonId", "ReasonName", "Statement");
                int dtcount = dt.Rows.Count;
                for (int j = 0; j < dtcount; j++)
                {
                    Rmreason.Add(new DEConsumerRMReasonResponse
                    {
                        ReasonId = Convert.ToInt32(dt.Rows[j]["ReasonId"].ToString()),
                        ReasonName = dt.Rows[j]["ReasonName"].ToString(),
                        Statement = dt.Rows[j]["Statement"].ToString(),
                        SubReason = GetRMChangeSubReason(dt2, Convert.ToInt32(dt.Rows[j]["ReasonId"].ToString())),
                    });
                }
            }
            return Rmreason;
        }
        public List<DEConsumerRMSubReasonResponse> GetRMChangeSubReason(DataTable dt, int ReasonId)
        {
            List<DEConsumerRMSubReasonResponse> rmsubreason = new List<DEConsumerRMSubReasonResponse>();
            DataRow[] dr = dt.Select("RefParentId=" + ReasonId);
            int cnt = dr.Length;
            for (int j = 0; j < cnt; j++)
            {
                rmsubreason.Add(new DEConsumerRMSubReasonResponse
                {
                    SubReasonId = Convert.ToInt32(dr[j]["SubReasonId"].ToString()),
                    SubReasonName = dr[j]["SubReasonName"].ToString(),
                });
            }
            return rmsubreason;
        }

        [HttpPost]
        [Route("SaveRMRating")]
        public IActionResult SaveRMRating(DERMRating req)
        {
            try
            {
                DAConsumerRM da = new DAConsumerRM();
                DEConsumerRM deRMrating = new DEConsumerRM();

                deRMrating.CallValue = DEConsumerRMCallValues.InsertRMRating;
                deRMrating.lead_hash = req.leadID;
                deRMrating.ActivityId = req.activityID;
                deRMrating.RMId = req.rMID;
                deRMrating.RatingID = req.ratingID;
                deRMrating.RatingDesc = req.ratingDesc;
                deRMrating.RatingValue = req.RatingValue;
                deRMrating.Remarks = req.remarks;
                deRMrating.ChangeRM = req.ChangeRM;

                var ds = da.Execute(deRMrating);

                string Message = deRMrating.dsResult.Tables[0].Rows[0]["Message"].ToString();

                if (deRMrating.dsResult != null && deRMrating.dsResult.Tables[0].Rows.Count > 0)
                {

                    deRMrating.RmRatingId = Utilities.ValidateInt(deRMrating.dsResult.Tables[0].Rows[0]["RmRatingId"].ToString());
                    if (deRMrating.RmRatingId == 0)
                    {
                        return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
                    }

                    if (req.rMFeedback != null)
                    {
                        foreach (var rmFeedback in req.rMFeedback)
                        {
                            deRMrating.CallValue = DEConsumerRMCallValues.InsertRMRatingFeedback;
                            deRMrating.FeedbackID = rmFeedback.feedbackID;
                            deRMrating.FeedbackDesc = rmFeedback.feedbackDesc;

                            var dsf = da.Execute(deRMrating);
                        }
                    }

                }
                if (ds.Tables.Count > 1)
                {


                    if (req.RatingValue == 1 || req.RatingValue == 2 || req.RatingValue == 3)
                    {
                        try
                        {
                            var dr = ds.Tables[1];
                            var unHappyEmailDetails = AppSettingsConf.EMailTemplatePath(MailDetails.UnhappyMailToSup);
                            var emailTemplate = _hostingEnvironment.ContentRootPath + unHappyEmailDetails.TemplateUrl;
                            string mailBody = string.Empty;
                            using (StreamReader reader = new StreamReader(emailTemplate))
                            {
                                mailBody = reader.ReadToEnd();
                            }
                            //var row = dr;

                            var mailSubject = unHappyEmailDetails.Subject
                                .Replace("{RMName}", dr.Rows[0]["RMName"].ToString());
                            mailBody = mailBody
                                .Replace("{Supervisor}", dr.Rows[0]["SupervisorName"].ToString())
                                .Replace("{RMName}", dr.Rows[0]["RMName"].ToString())
                                .Replace("{LeadID}", dr.Rows[0]["LeadID"].ToString())
                                .Replace("{CustomerName}", dr.Rows[0]["CustomerName"].ToString())
                                .Replace("{LeaderName}", dr.Rows[0]["LeaderName"].ToString());
                            var mailTo = Convert.ToString(dr.Rows[0]["Email"].ToString());
                            var mailCc = Convert.ToString(dr.Rows[0]["CCEmails"].ToString());
                            var mailBcc = Convert.ToString(dr.Rows[0]["BCCEmails"].ToString());
                            SendMail.f_sendMailFromCRM(mailTo, mailCc, mailBcc, "", mailBody, mailSubject, null);
                            Console.WriteLine("Mail sent successfully to supervisor");
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine(" Error UnHappy Mail To Supervisor \n" + ex);
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Happy");
                }

                return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
        [HttpPost, Route("GetTestimonial")]
        public IActionResult GetTestimonial(TestimonialDTO req)
        {
            try
            {
                DAConsumerRM da = new DAConsumerRM();
                DEConsumerRM de = new DEConsumerRM()
                {
                    CallValue = DEConsumerRMCallValues.GetTestimonial,
                    RMId = req.rmId,
                    PageNo = req.pageNo,
                    Limit = req.limit
                };
                var ds = da.Execute(de);
                var FilterRes = ds.Tables[0];
                var pageinfo = ds.Tables[1];
                //var MaxNumberOfPages = pageinfo.Rows[1]["MaxNumberOfPages"];
                //var CurrentPage = pageinfo.Rows[1]["CurrentPage"];
                if (FilterRes.Rows.Count > 0)
                {
                    var data = new
                    {
                        pageinfo,
                        FilterRes
                    };
                    return ApiHelper.CreateSuccessResponse(this, data);
                }
                else
                    return ApiHelper.CreateSuccessResponse(this, "No record found");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}
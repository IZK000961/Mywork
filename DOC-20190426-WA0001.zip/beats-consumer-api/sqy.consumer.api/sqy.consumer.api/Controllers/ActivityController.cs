﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using sqy.consumer.api.DTO;
using sqy.consumer.api.Middleware;
using sqy.consumer.DataAccess;
using sqy.consumer.DataEntities;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ActivityController : ControllerBase
    {
        [HttpGet]
        [Route("GetUpcomingActivity")]
        public IActionResult UpcomingActivity(string lead_id)
        {
            try
            {
                if (lead_id == null)
                {
                    return NotFound();
                }
                DAConsumerRM da = new DAConsumerRM();
                DEConsumerRM de = new DEConsumerRM()
                {
                    CallValue = DEConsumerRMCallValues.GetUpcomingActivity,
                    lead_hash = lead_id
                };

                var ds = da.Execute(de);

                var FilterRes = ds.Tables[0];
                if (FilterRes.Rows.Count > 0)
                {
                    var data = new
                    {
                        FilterRes
                    };
                    return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
                }
                else
                    return ApiHelper.CreateSuccessResponse(this, "No record found");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpGet]
        [Route("GetRecentActivity")]
        public IActionResult RecentActivity([FromHeader]GetRecentActivityRequestDTO req)
        {
            try
            {
                if (req.lead_id == null)
                {
                    return NotFound();
                }
                DAConsumerRM da = new DAConsumerRM();
                DEConsumerRM de = new DEConsumerRM()
                {
                    CallValue = DEConsumerRMCallValues.GetRecentActivity,
                    lead_hash = req.lead_id,
                    PageNo= req.pageNo,
                    Limit= req.limit
                };

                var ds = da.Execute(de);

                var FilterRes = ds.Tables[0];
                var pageinfo = ds.Tables[1];
                //var MaxNumberOfPages = pageinfo.Rows[1]["MaxNumberOfPages"];
                //var CurrentPage = pageinfo.Rows[1]["CurrentPage"];
                if (FilterRes.Rows.Count > 0)
                {
                    var data = new
                    {
                        pageinfo,
                        FilterRes
                    };
                    return ApiHelper.CreateSuccessResponse(this, data);
                }
                else
                    return ApiHelper.CreateSuccessResponse(this, "No record found");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost]
        [Route("ResecheduleActivity")]
        public IActionResult ResecheduleActivity([FromBody] ResecheduleActivityDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    DAConsumerRM da = new DAConsumerRM();
                    DEConsumerRM de = new DEConsumerRM()
                    {
                        CallValue = DEConsumerRMCallValues.AddResecheduleActivity,
                        ActivityId = req.ActivityId,
                        ChangeReason = req.Reason,
                        NextInteractionDate = DateTime.ParseExact(req.NextInteractionDate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        //Updatedby = 1
                    };

                    var ds = da.Execute(de);

                    var FilterRes = ds.Tables[0];
                    //var MaxNumberOfPages = ds.Tables[1].Rows[0]["MaxNumberOfPages"];
                    //var CurrentPageNo = ds.Tables[1].Rows[0]["MaxNumberOfPages"];
                    //var FilterInfo = ds.Tables[1].Rows[0]["FilterInfo"];

                    var data = new
                    {
                        FilterRes
                    };


                    return ApiHelper.CreateSuccessResponse(this, ds.Tables[0]);
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }

        [HttpPost]
        [Route("UpdateActivityFeedback")]
        public IActionResult UpdateActivityFeedback([FromBody] FeedbackActivityDTO req)
        {
            try
            {
                if (ModelState.IsValid)
                {

                    DAConsumerRM da = new DAConsumerRM();
                    DEConsumerRM de = new DEConsumerRM()
                    {
                        CallValue = DEConsumerRMCallValues.UpdateActivityFeedback,
                        ActivityId = req.ActivityId,
                        FeedbackRatings = req.FeedbackRatings,
                        //NextInteractionDate = DateTime.ParseExact(req.NextInteractionDate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture),
                        //Updatedby = 1
                    };

                    var ds = da.Execute(de);
                    return ApiHelper.CreateSuccessResponse(this, "Feedback Updated");
                }
                else
                {
                    var error = ModelState.Values.Where(v => v.Errors.Count > 0)
                        .FirstOrDefault()
                        .Errors[0]
                        .ErrorMessage;
                    throw new ApplicationException(error);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception:" + ex.Message + "\n" + ex.StackTrace);
                return ApiHelper.CreateErrorResponse(this, ex.Message);
            }
        }
    }
}
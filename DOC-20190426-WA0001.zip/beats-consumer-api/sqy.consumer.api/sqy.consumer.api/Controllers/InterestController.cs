﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using sqy.consumer.api.DTO;
using sqy.consumer.api.Middleware;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;

namespace sqy.consumer.api.Controllers
{
    [ConsumerAuthorize]
    [Route("api/[controller]")]
    [ApiController]
    public class InterestController : ControllerBase
    {
        private readonly AppSettingsMongoDb _context;
        public InterestController(IOptions<AppSettingsMongoDb> AppSettingsMongoDb)
        {
            _context = AppSettingsMongoDb.Value;
        }
        private IMongoDatabase mongoDatabase;
        //Generic method to get the mongodb database details  
        public IMongoDatabase GetMongoDatabase()
        {
            var mongoClient = new MongoClient(_context.MongoConnection);
            return mongoClient.GetDatabase(_context.MongoDatabase);
        }
        [HttpGet, Route("GetIntrestedProject")]
        public IActionResult IntrestedProject(string lead_Id)
        {
            try
            {
                if (lead_Id == null)
                {
                    return NotFound();
                }
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
               
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", lead_Id);
                var result = collection.Find(filter).ToList();
                var result1 = result[0].interests;
                var afterorde = result1.OrderByDescending(x => x.date_added).ToList();

                if (afterorde.Count>0)
                {
                    return ApiHelper.CreateSuccessResponse(this, afterorde);
                }
                else
                {
                    return ApiHelper.CreateErrorResponse(this, "No records found");
                }
                //var customer = mongoDatabase.GetCollection<Consumer>("consumer").Find<Consumer>(k => k.interests[0].project_id == req.project_id).ToList();
                
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost, Route("AddIntrestedProject")]
        public IActionResult AddIntrestedProject([FromBody] Addinterestsdto req)
        {
            try
            {
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", req.lead_Id);
                var result = collection.Find(filter).ToList();
                var inte = result[0].interests.ToList();
                var project = inte.Find(X => X.project_id == req.project_id || X.project_name==req.project_name);
                if(project==null)
                {

                    var cudt = new interests()
                    {
                        project_id = req.project_id,
                        project_name = req.project_name,
                        project_address = req.project_address,
                        project_city = req.project_city,
                        project_city_id=req.project_city_id,
                        project_country_id = req.project_country_id,
                        date_added = req.date_added,
                        project_flagship = req.project_flagship

                    };
                    var updater = Builders<Consumer>.Update.AddToSet("interests", cudt);
                    collection.UpdateOne(filter, updater);
                    return ApiHelper.CreateSuccessResponse(this, "Submitted");
                }
                else
                {
                    var findrec = new BsonDocument("lead.lead_hash", req.lead_Id);
                    var update = Builders<Consumer>.Update.PullFilter("interests", Builders<interests>.Filter.Eq("project_id", req.project_id));
                    var delrec = collection.FindOneAndUpdateAsync(findrec, update).Result;

                    return ApiHelper.CreateErrorResponse(this, "records " + req.project_id + " delete");
                }

                
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost, Route("AddProject")]
        public IActionResult AddProject([FromBody] AddProjectdto req)
        {
            try
            {
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = Builders<Consumer>.Filter.Eq("lead.lead_hash", req.lead_hash);
                var result = collection.Find(filter).ToList();
                if (result.Count > 0)
                {
                    var inte = result[0].interests.ToList();
                    if (req.project_id != 0)
                    {
                        var project = inte.Find(X => X.project_id == req.project_id || X.project_name == req.project_name);
                        if (project == null)
                        {

                            var cudt = new interests()
                            {
                                project_id = req.project_id,
                                project_name = req.project_name,
                                project_address = req.project_address,
                                project_city = req.project_city,
                                project_country_id = req.project_country_id,
                                project_city_id = req.project_city_id,
                                date_added = req.date_added,
                                project_flagship = req.project_flagship

                            };
                            var updater = Builders<Consumer>.Update.AddToSet("interests", cudt);
                            collection.UpdateOne(filter, updater);
                            return ApiHelper.CreateSuccessResponse(this, "Submitted");
                        }
                        else
                        {
                            return ApiHelper.CreateErrorResponse(this, "Project allready found!");
                        }
                    }
                    else
                    {
                        var project = inte.Find(X => X.project_name == req.project_name);
                        if (project == null)
                        {

                            var cudt = new interests()
                            {
                                project_id = req.project_id,
                                project_name = req.project_name,
                                project_address = req.project_address,
                                project_city = req.project_city,
                                project_city_id = req.project_city_id,
                                date_added = req.date_added,
                                project_flagship = req.project_flagship

                            };
                            var updater = Builders<Consumer>.Update.AddToSet("interests", cudt);
                            collection.UpdateOne(filter, updater);
                            return ApiHelper.CreateSuccessResponse(this, "Submitted");
                        }
                        else
                        {
                            return ApiHelper.CreateErrorResponse(this, "Project allready found!");
                        }
                    }

                }
                else
                {
                    return ApiHelper.CreateErrorResponse(this, "Lead id not found");
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        [HttpPost, Route("RemoveIntrestedProject")]
        public IActionResult RemoveIntrestedProject([FromBody] Removeinterestsdto req)
        {
            try
            {
                if (req.lead_Id==null)
                {
                    return NotFound();
                }
                //Get the database connection  
                mongoDatabase = GetMongoDatabase();
                var collection = mongoDatabase.GetCollection<Consumer>("consumer");
                var filter = new BsonDocument("lead.lead_hash", req.lead_Id);
                var update = Builders<Consumer>.Update.PullFilter("interests",Builders<interests>.Filter.Eq("project_id", req.project_id));
                var result = collection.FindOneAndUpdateAsync(filter, update).Result;

                return ApiHelper.CreateErrorResponse(this, "records "+req.project_id+" delete");
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}
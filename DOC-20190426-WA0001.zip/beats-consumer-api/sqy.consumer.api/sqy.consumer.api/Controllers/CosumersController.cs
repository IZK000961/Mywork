﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace sqy.consumer.api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CosumersController : ControllerBase
    {
        private readonly IConsumerRepository _consumerRepository;
        public CosumersController(IConsumerRepository cosumerRepository)
        {
            _consumerRepository = cosumerRepository;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            return new ObjectResult(await _consumerRepository.GetAllConsumer());
        }
        // GET: api/Game/name
        [HttpGet,Route("Get")]
        public async Task<IActionResult> Get(int lead_Id)
        {
            var game = await _consumerRepository.GetConsumer(lead_Id);
            if (game == null)
                return new NotFoundResult();
            return new ObjectResult(game);
        }
    }
}
﻿using MongoDB.Driver;
using sqy.consumer.DataEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api
{
    public class ConsumerRepository : IConsumerRepository
    {
        private readonly IMongoDBContext _context;
        public ConsumerRepository(IMongoDBContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Consumer>> GetAllConsumer()
        {
            return await _context
            .Consumers
            .Find(_=> true)
            .ToListAsync();
        }
        public Task<Consumer> GetConsumer(int lead_Id)
        {
            FilterDefinition<Consumer> filter = Builders<Consumer>.Filter.Eq("lead.lead_id", lead_Id);
            return _context
            .Consumers
            .Find(filter)
            .FirstOrDefaultAsync();
        }
        public async Task Create(Consumer consumer)
        {
            await _context.Consumers.InsertOneAsync(consumer);
        }

        public async Task<bool> Update(Consumer consumer)
        {
            ReplaceOneResult updateResult =
            await _context
            .Consumers
            .ReplaceOneAsync(
            filter: g => g.id == consumer.id,
            replacement: consumer);
            return updateResult.IsAcknowledged
            && updateResult.ModifiedCount > 0;
        }
        public async Task<bool> Delete(int lead_Id)
        {
            FilterDefinition<Consumer> filter = Builders<Consumer>.Filter.Eq("lead.lead_id", lead_Id);
            DeleteResult deleteResult = await _context
            .Consumers
            .DeleteOneAsync(filter);
            return deleteResult.IsAcknowledged
            && deleteResult.DeletedCount > 0;
        }
    }
    public interface IConsumerRepository
    {
        Task<IEnumerable<Consumer>> GetAllConsumer();
        Task<Consumer> GetConsumer(int lead_Id);
        Task Create(Consumer consumer);
        Task<bool> Update(Consumer consumer);
        Task<bool> Delete(int lead_Id);
    }
}

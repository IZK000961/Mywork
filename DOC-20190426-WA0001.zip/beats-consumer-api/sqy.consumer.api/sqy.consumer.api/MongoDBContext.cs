﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api
{
    public class MongoDBContext: IMongoDBContext
    {
        public static string ConnectionString { get; set; }
        public static string DatabaseName { get; set; }
        public static bool IsSSL { get; set; }

        private readonly IMongoDatabase _db;

        public MongoDBContext(IOptions<AppSettingsMongoDb> options)
        {
            var client = new MongoClient(options.Value.ConnectionString);
            _db = client.GetDatabase(options.Value.Database);
        }
        public IMongoCollection<Consumer> Consumers => _db.GetCollection<Consumer>("consumer");

       
    }
    public interface IMongoDBContext
    {
        IMongoCollection<Consumer> Consumers { get; }
    }
}

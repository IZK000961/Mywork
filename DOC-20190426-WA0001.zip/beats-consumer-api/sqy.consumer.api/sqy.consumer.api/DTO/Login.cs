﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api.DTO
{
    public class LoginRequestDTO
    {
        public string CountryCode { get; set; }
        public string PhoneNumber { get; set; }
        public int RequestId { get; set; } = 0;
        public int SegmentId { get; set; }
    }
    public class LoginOTPDTO
    {
        public int requestId { get; set; }
        public int OTP { get; set; } = 0;
    }
    public class LoginResponseDTO
    {
        public int RequestId { get; set; }
        public string OTP { get; set; }
    }
}

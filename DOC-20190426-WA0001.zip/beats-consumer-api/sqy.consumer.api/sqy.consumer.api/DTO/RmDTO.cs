﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api.DTO
{
    public class RmDTO
    {
        public string Lead_Id { get; set; }
        public string lead_hash { get; set; }
        public int RMId { get; set; }
        public string Reason { get; set; }
        public string SubReason { get; set; }
        public string Remarks { get; set; }
        public DateTime RequestDate { get; set; }
        public string ProcessDate { get; set; }
        public string client_city { get; set; }
        public bool ChangeRM { get; set; }

        //public List<lead> lead { get; set; }
        //public List<interests> interests { get; set; }
        public LastKnown last_known { get; set; }

        public DateTime created_on { get; set; } = DateTime.Now;

        public DateTime updated_on { get; set; } = DateTime.Now;
    }

    public class ResecheduleActivityDTO
    {
        public int ActivityId { get; set; }
        public string Reason { get; set; }
        public DateTime RequestDate { get; set; }
        public string NextInteractionDate { get; set; }
        //public List<lead> lead { get; set; }
        //public List<interests> interests { get; set; }
        //public LastKnown last_known { get; set; }

        public DateTime created_on { get; set; } = DateTime.Now;

        public DateTime updated_on { get; set; } = DateTime.Now;
    }
    public class FeedbackActivityDTO
    {
        public int ActivityId { get; set; }
        public int FeedbackRatings { get; set; }
    }
}

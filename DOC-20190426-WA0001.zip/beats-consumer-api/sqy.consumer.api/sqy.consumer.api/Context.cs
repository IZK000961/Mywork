﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace sqy.consumer.api
{
    public class Context
    {
        public string MongoConnection { get; set; }
    }
}

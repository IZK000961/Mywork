﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.consumer.Helper
{
    public class AppSettingsMongoDb
    {
        public string MongoConnection { get; set; }
        public string MongoDatabase { get; set; }
    }
}

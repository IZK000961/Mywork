﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Configuration;

namespace sqy.consumer.Helper
{
    public class MailConfigKeys
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string SMTP { get; set; }
        public string SMTPPort { get; set; }
    }
    public enum MailType
    {
        AWS
    }
    public enum SMSType
    {
        SMS
    }
    public enum EmailFrom
    {
        HR,
        CRM,
        NoReply
    }
    public enum MailDetails
    {
        UnhappyMailToSup
    }

    public class EmailKeys
    {
        public int Testing { get; set; }
        public string TestMailTo { get; set; }
    }
    public class SMSConfigKeys
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string vkey { get; set; }
        public string DomesticUrl { get; set; }
        public string GlobalUrl { get; set; }
        public string Apikey { get; set; }
        public string GCCUrl { get; set; }
    }
    public class SMSKeys
    {
        public int Testing { get; set; }
        public string TestMobileNo { get; set; }
        public string DomesticSMS { get; set; }
        public string GlobalHappysms { get; set; }
        public string GlobalUnHappysms { get; set; }
        public string GCCMsg { get; set; }
        public string OTPMsgForPWAUrl { get; set; }
    }
    public class EmailMeta
    {
        public string FromAccount { get; set; }
        public string Address { get; set; }
        public string DisplayName { get; set; }
        public string MailBCC { get; set; }
    }
    public class EmailTemplate
    {
        public string Subject { get; set; }
        public string TemplateUrl { get; set; }
    }

    public static class AppSettingsConf
    {
        public static IConfiguration Configuration { get; set; }

        public static string GetConnectionString(string name)
        {
            return Configuration.GetConnectionString(name);
        }
        public static MailConfigKeys GetMailSettings(MailType mailType)
        {
            MailConfigKeys keys = new MailConfigKeys();
            var section = Configuration.GetSection("MailConfigKeys").GetSection(mailType.ToString());

            keys.UserName = section["Username"];
            keys.Password = section["Password"];
            keys.SMTP = section["SMTP"];
            keys.SMTPPort = section["SMTPPort"];

            return keys;
        }

        public static EmailMeta EMailMetaSettings(EmailFrom mailType)
        {
            EmailMeta keys = new EmailMeta();
            var section = Configuration.GetSection("MailMeta").GetSection(mailType.ToString());

            keys.Address = section["Address"];
            keys.DisplayName = section["DisplayName"];
            keys.FromAccount = section["FromAccount"];
            keys.MailBCC = section["MailBCC"];

            return keys;
        }

        public static EmailKeys EMailKeySettings()
        {
            EmailKeys keys = new EmailKeys();
            var section = Configuration.GetSection("EmailKeys");

            keys.Testing = Convert.ToInt32(section["Testing"]);
            keys.TestMailTo = section["TestMailTo"];

            return keys;
        }

        public static EmailTemplate EMailTemplatePath(MailDetails mailDetails)
        {
            EmailTemplate key = new EmailTemplate();

            if (Configuration.GetSection("MailDetails").GetSection(mailDetails.ToString()) == null)
                throw new ApplicationException("MailDetails not found in config" + mailDetails);
            var section = Configuration.GetSection("MailDetails").GetSection(mailDetails.ToString());
            key.Subject = section["Subject"];
            key.TemplateUrl = section["TemplateUrl"];
            return key;
        }

        public static SMSConfigKeys SendSMSSettings(SMSType smsType)
        {
            SMSConfigKeys keys = new SMSConfigKeys();
            var section = Configuration.GetSection("SMSConfigKeys").GetSection(smsType.ToString());

            keys.UserName = section["Username"];
            keys.Password = section["Password"];
            keys.vkey = section["verification_key"];
            keys.DomesticUrl = section["DomesticUrl"];
            keys.GlobalUrl = section["Globalurl"];
            keys.Apikey = section["Apikey"];
            keys.GCCUrl = section["GCCUrl"];
            return keys;
        }
        public static SMSKeys SMSKeySettings()
        {
            SMSKeys keys = new SMSKeys();
            var section = Configuration.GetSection("SMSKeys");

            keys.Testing = Convert.ToInt32(section["Testing"]);
            keys.TestMobileNo = section["TestMobileNo"];
            keys.DomesticSMS = section["DomesticMsg"];
            keys.GlobalHappysms = section["GlobalHappyOTPTemplate"];
            keys.GlobalUnHappysms = section["GlobalUnHappyOTPTemplate"];
            keys.GCCMsg = section["GCCMsg"];
            keys.OTPMsgForPWAUrl = section["OTPMsgForPWAUrl"];

            return keys;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System.Configuration;
using System.Collections.Specialized;
using Amazon.Runtime;
using Amazon.S3.Transfer;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace sqy.beats.Framework
{
    public class AmazonS3Upload
    {
        static NameValueCollection appConfig = GetConnectionString.AppSettings;
        private const string BUCKET_NAME = "sqy";
        public enum S3Folder
        {
            Projects,
            Units,
            ClientDocs,
            BookingDocs,
            LoanDocs, KYCDocs, TCFInvoiceDocs,
            BankDoc, ClientDocMCF, SancDocMCF,
            TCFCollectionDocs, PaymentUpload, MCFInvoiceDocs, MCFCollectionDocs, MCFUploadInvoiceDocs, MCFUploadCollectionDocs,
            TrovitFeed,MitulaFeed, TCFUploadInvoiceDocs, TCFUploadCollectionDocs
        }
        /// <summary>
        /// Upload file on AWS S3
        /// </summary>
        /// <param name="folder">S3Folder enum</param>
        /// <param name="filePath">full path of the file</param>
        /// <param name="fileName">file name</param>
        public static bool Upload(S3Folder folder, string filePath, string fileName)
        {
            try
            {
                string S3_KEY = string.Empty;
                switch (folder)
                {
                    case S3Folder.Projects:
                        S3_KEY = appConfig["AWSPath_Projects"] + fileName;
                        break;
                    case S3Folder.Units:
                        S3_KEY = appConfig["AWSPath_Units"] + fileName;
                        break;
                    case S3Folder.ClientDocs:
                        S3_KEY = appConfig["AWSPath_ClientDocs"] + fileName;
                        break;
                    case S3Folder.BookingDocs:
                        S3_KEY = appConfig["AWSPath_BookingDocs"] + fileName;
                        break;
                    case S3Folder.LoanDocs:
                        S3_KEY = appConfig["AWSPath_LoanDocs"] + fileName;
                        break;
                    case S3Folder.KYCDocs:
                        S3_KEY = appConfig["AWSPath_KYCDocs"] + fileName;
                        break;
                    case S3Folder.TCFInvoiceDocs:
                        S3_KEY = appConfig["AWSPath_TCFInvoice"] + fileName;
                        break;
                    case S3Folder.TCFCollectionDocs:
                        S3_KEY = appConfig["AWSPath_TCFCollection"] + fileName;
                        break;

                    case S3Folder.BankDoc:
                        S3_KEY = appConfig["AWSPath_MCFBankDocs"] + fileName;
                        break;
                    case S3Folder.ClientDocMCF:
                        S3_KEY = appConfig["AWSPath_MCFClientDocs"] + fileName;
                        break;
                    case S3Folder.SancDocMCF:
                        S3_KEY = appConfig["AWSPath_SancDocMCF"] + fileName;
                        break;
                    case S3Folder.PaymentUpload:
                        S3_KEY = appConfig["AWSPath_CPPaymentUpload"] + fileName;
                        break;
                    case S3Folder.MCFInvoiceDocs:
                        S3_KEY = appConfig["AWSPath_MCFInvoice"] + fileName;
                        break;
                    case S3Folder.MCFCollectionDocs:
                        S3_KEY = appConfig["AWSPath_MCFCollection"] + fileName;
                        break;
                    case S3Folder.MCFUploadInvoiceDocs:
                        S3_KEY = appConfig["AWSPath_MCFUploadInvoice"] + fileName;
                        break;
                    case S3Folder.MCFUploadCollectionDocs:
                        S3_KEY = appConfig["AWSPath_MCFUploadCollection"] + fileName;
                        break;
                    case S3Folder.TrovitFeed:
                        S3_KEY = appConfig["AWSPath_TrovitFeed"] + fileName;
                        break;
                    case S3Folder.MitulaFeed:
                        S3_KEY = appConfig["AWSPath_MitulaFeed"] + fileName;
                        break;
                    case S3Folder.TCFUploadInvoiceDocs:
                        S3_KEY = appConfig["AWSPath_TCFUploadInvoice"] + fileName;
                        break;
                    case S3Folder.TCFUploadCollectionDocs:
                        S3_KEY = appConfig["AWSPath_TCFUploadCollection"] + fileName;
                        break;
                    default:
                        break;
                }
                // Create S3 service client.
                using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
                {
                    // Setup request for putting an object in S3.
                    var request = new PutObjectRequest
                    {
                        BucketName = BUCKET_NAME,
                        Key = S3_KEY,
                        FilePath = filePath
                    };

                    // Make service call and get back the response.
                    s3Client.PutObjectAsync(request);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Delete file on AWS S3
        /// </summary>
        /// <param name="folder">S3Folder enum</param>
        /// <param name="fileName">file name</param>
        public static bool Delete(S3Folder folder, string fileName)
        {
            try
            {
                string S3_KEY = string.Empty;
                switch (folder)
                {
                    case S3Folder.Projects:
                        S3_KEY = appConfig["AWSPath_Projects"] + fileName;
                        break;
                    case S3Folder.Units:
                        S3_KEY = appConfig["AWSPath_Units"] + fileName;
                        break;
                    case S3Folder.ClientDocs:
                        S3_KEY = appConfig["AWSPath_ClientDocs"] + fileName;
                        break;
                    case S3Folder.BookingDocs:
                        S3_KEY = appConfig["AWSPath_BookingDocs"] + fileName;
                        break;
                    default:
                        break;
                }
                // Create S3 service client.
                using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
                {
                    // Setup request for putting an object in S3.
                    var request = new DeleteObjectRequest
                    {
                        BucketName = BUCKET_NAME,
                        Key = S3_KEY
                    };

                    // Make service call and get back the response.
                    s3Client.DeleteObjectAsync(request);
                }
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Upload file to S3
        /// </summary>
        /// <param name="fileStream">PostedFile.InputStream</param>
        /// <param name="bucketNameInS3">Use Bucket Name with File name (bucketname/file.extension)</param>
        /// <param name="disabletesting">Use 1 for move file in actual bucket other wise depend on appconfig testing key</param>
        /// <returns></returns>
        public static bool Upload(Stream fileStream, string bucketNameInS3, int disabletesting = 0)
        {
            if (appConfig["testing"] == "1" && disabletesting != 1)
            {
                string[] file = bucketNameInS3.Split('/');
                bucketNameInS3 = "testing/" + file.LastOrDefault();
            }
            string S3_KEY = bucketNameInS3;
            using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
            {
                // Setup request for putting an object in S3.
                var Putrequest = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY,
                    InputStream = fileStream
                };
                // Make service call and get back the response.
                s3Client.PutObjectAsync(Putrequest);
            }
            return true;
        }
        public static bool Upload(Stream fileStream, string bucketNameInS3, bool isOptimizeImg)
        {
            if (appConfig["testing"] == "1")
            {
                bucketNameInS3 = string.Concat("testing/", bucketNameInS3);
            }
            string S3_KEY = bucketNameInS3;
            using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
            {
                // Setup request for putting an object in S3.
                var Putrequest = new PutObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY,
                    InputStream = fileStream
                };
                // Make service call and get back the response.
                s3Client.PutObjectAsync(Putrequest);
                if (isOptimizeImg)
                    doOptimization(S3_KEY);
            }
            return true;
        }
        public static bool Delete(string fileNameInS3, int disabletesting = 0)
        {
            if (appConfig["testing"] == "1" && disabletesting != 1)
            {
                string[] file = fileNameInS3.Split('/');
                fileNameInS3 = "testing/" + file.LastOrDefault();
            }
            string S3_KEY = fileNameInS3;
            using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
            {
                // Setup request for putting an object in S3.
                var request = new DeleteObjectRequest
                {
                    BucketName = BUCKET_NAME,
                    Key = S3_KEY
                };
                // Make service call and get back the response.
                s3Client.DeleteObjectAsync(request);
            }
            return true;
        }
        public static bool Exists(string fileKey)
        {
            try
            {
                if (appConfig["testing"] == "1")
                {
                    fileKey = string.Concat("testing/", fileKey);
                }
                using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
                {
                    var s3FileInfo = new Amazon.S3.IO.S3FileInfo(s3Client, BUCKET_NAME, fileKey);
                    return s3FileInfo.Exists;
                }
            }

            catch (Amazon.S3.AmazonS3Exception ex)
            {
                if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return false;
                //status wasn't not found, so throw the exception
                throw new ApplicationException(ex.Message);
            }
        }

        public static bool Move(string sourcefileKey,string desfileKey)
        {
            using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
            {
                S3FileInfo source = new S3FileInfo(s3Client, BUCKET_NAME, sourcefileKey);
                S3FileInfo destination = new S3FileInfo(s3Client, BUCKET_NAME, desfileKey);
                //source.CopyTo(destination);
                source.MoveTo(destination);
            }
            return true;
        }

        public static List<string> GetBuketObjectName(string Prefix)
        {
            List<string> objects = new List<string>();
            using (IAmazonS3 s3Client = new AmazonS3Client(appConfig["AWSAccessKey"], appConfig["AWSSecretKey"], RegionEndpoint.APSoutheast1))
            {
                ListObjectsRequest request = new ListObjectsRequest();
                request.BucketName = BUCKET_NAME;
                request.Prefix = Prefix;
                ListObjectsResponse response = s3Client.ListObjects(request);
                foreach (S3Object o in response.S3Objects)
                {
                    objects.Add(o.Key);
                    //Console.WriteLine("{0}\t{1}\t{2}", o.Key, o.Size, o.LastModified);
                }
            }
            return objects;
        }
        static void doOptimization(string imagepath)
        {
            string key = appConfig["tinypng_apikey"];
            string url = appConfig["tinypng_apiurl"];
            
            string input = string.Concat(appConfig["AWSPath"], imagepath);

            System.Net.WebClient client = new System.Net.WebClient();
            string auth = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("api:" + key));
            client.Headers.Add(System.Net.HttpRequestHeader.Authorization, "Basic " + auth);
            client.Headers[System.Net.HttpRequestHeader.ContentType] = "application/json";
            try
            {
                string json = "{\"source\":{\"url\":\"" + input + "\"}}";
                var response = client.UploadString(url, json);
                /* Compression was successful, retrieve output from Location header. */
                optimizeUpload(imagepath, client.ResponseHeaders["Location"]);
            }
            catch (System.Net.WebException wex)
            {
                /* Something went wrong! You can parse the JSON body for details. */
                throw new ApplicationException(wex.Message);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null) ex = ex.InnerException;
                throw new ApplicationException(ex.Message);
            }
        }

        static void optimizeUpload(string imagepath, string url)
        {
            string key = appConfig["tinypng_apikey"];
            System.Net.WebClient client = new System.Net.WebClient();
            string auth = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("api:" + key));
            client.Headers.Add(System.Net.HttpRequestHeader.Authorization, "Basic " + auth);
            client.Headers[System.Net.HttpRequestHeader.ContentType] = "application/json";
            try
            {
                string imgPath = string.Concat(BUCKET_NAME, "/", imagepath);
                store store = new store() {
                    aws_access_key_id = appConfig["AWSAccessKey"],
                    aws_secret_access_key = appConfig["AWSSecretKey"],
                    region = RegionEndpoint.APSoutheast1.SystemName,
                    path = imgPath
                };
                tinypng tpng = new tinypng()
                {
                    store = store
                };
                JsonSerializerSettings settings = new JsonSerializerSettings();
                settings.ContractResolver = new CamelCasePropertyNamesContractResolver();
                var data = JsonConvert.SerializeObject(tpng, settings);
                var response = client.UploadString(url, data);
            }
            catch (System.Net.WebException wex)
            {
                /* Something went wrong! You can parse the JSON body for details. */
                throw new ApplicationException(wex.Message);
            }
            catch (Exception ex)
            {
                while (ex.InnerException != null) ex = ex.InnerException;
                throw new ApplicationException(ex.Message);
            }
        }

        class tinypng
        {
            public store store { get; set; }
        }

        class store
        {
            public string service { get; set; } = "s3";
            public string aws_access_key_id { get; set; }
            public string aws_secret_access_key { get; set; }
            public string region { get; set; }
            public string path { get; set; }
        }
    }
}

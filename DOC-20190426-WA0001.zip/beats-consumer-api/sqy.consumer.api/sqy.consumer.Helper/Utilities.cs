﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.consumer.Helper
{
    public class Utilities
    {
        public static DateTime ValidateDate(object date, bool minDate)
        {
            try
            {
                DateTime dt = Convert.ToDateTime(date);
                return dt;
            }
            catch (Exception)
            {
                if (minDate)
                    return DateTime.MinValue;
                else
                    return DateTime.MaxValue;
            }
        }
        public static DateTime ValidateDateTime(object val, DateTime defaultVal)
        {
            DateTime id;
            var isValid = DateTime.TryParse(Convert.ToString(val), out id);
            return (isValid) ? id : defaultVal;
        }
        public static int ValidateInt(object val, int defaultVal = 0)
        {
            int id;
            var isValid = int.TryParse(Convert.ToString(val), out id);
            return (isValid) ? id : defaultVal;
        }
        public static double ValidateDouble(object val, double defaultVal = 0)
        {
            double id;
            var isValid = double.TryParse(Convert.ToString(val), out id);
            return (isValid) ? id : defaultVal;
        }
        public static bool ValidateBool(object val, bool defaultVal = false)
        {
            bool res = defaultVal;
            if (Convert.ToString(val).Equals("true", StringComparison.OrdinalIgnoreCase) || val.Equals("1") || Convert.ToString(val).Equals("yes", StringComparison.OrdinalIgnoreCase))
            {
                res = true;
            }
            else if (Convert.ToString(val).Equals("false", StringComparison.OrdinalIgnoreCase) || val.Equals("0") || Convert.ToString(val).Equals("no", StringComparison.OrdinalIgnoreCase))
            {
                res = false;
            }

            return res;
        }
        public static decimal ValidateDecimal(object val, decimal defaultVal = 0)
        {
            decimal id;
            var isValid = decimal.TryParse(Convert.ToString(val), out id);
            return (isValid) ? id : defaultVal;
        }
    }
}

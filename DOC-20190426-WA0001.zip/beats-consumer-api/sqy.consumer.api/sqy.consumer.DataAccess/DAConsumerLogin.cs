﻿using MySql.Data.MySqlClient;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.consumer.DataAccess
{
    public class DAConsumerLogin
    {
        public MySqlDbHelper mySqlDbHelper { get; set; }
        public DAConsumerLogin(string connectionName = "beats")
        {
            var connectionString = AppSettingsConf.GetConnectionString(connectionName);
            mySqlDbHelper = new MySqlDbHelper(connectionString);
        }
        public DataSet Execute(DEConsumerLogin de)
        {
            var parameters = new List<MySqlParameter>();
            mySqlDbHelper.SetParameters(parameters, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlDbHelper.SetParameters(parameters, "_RequestID", MySqlDbType.Int32, de.RequestId);
            mySqlDbHelper.SetParameters(parameters, "_OTP", MySqlDbType.Int32, de.OTP);
            mySqlDbHelper.SetParameters(parameters, "_segmentId", MySqlDbType.Int32, de.SegmentId);
            mySqlDbHelper.SetParameters(parameters, "_PhoneNumber", MySqlDbType.VarChar, de.PhoneNumber);
            mySqlDbHelper.SetParameters(parameters, "_CountryCode", MySqlDbType.VarChar, de.CountryCode);
            mySqlDbHelper.SetParameters(parameters, "_ApiAccessToken", MySqlDbType.VarChar, de.Token);
            de.dsResult = mySqlDbHelper.Execute("udsp_ConsumerPwaOTP", parameters);
            return de.dsResult;
        }
    }
}

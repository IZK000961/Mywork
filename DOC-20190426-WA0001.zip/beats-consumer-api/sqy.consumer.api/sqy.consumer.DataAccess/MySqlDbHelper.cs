﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.consumer.DataAccess
{
    public class MySqlDbHelper
    {
        public string ConnectionString { get; set; }
        public MySqlDbHelper(string connectionString)
        {
            this.ConnectionString = connectionString;
        }


        public void SetParameters(List<MySqlParameter> parameters, string parameterName, MySqlDbType mySqlDbType, object value)
        {
            MySqlParameter mySqlParameter = new MySqlParameter(parameterName, mySqlDbType)
            {
                Value = value
            };
            parameters.Add(mySqlParameter);
        }

        public DataSet Execute(string procedureName, List<MySqlParameter> parameters)
        {
            using (MySqlConnection con = new MySqlConnection(ConnectionString))
            {
                using (MySqlCommand cmd = new MySqlCommand(procedureName, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandTimeout = 0;
                    con.Open();
                    for (int i = 0; i < parameters.Count; i++)
                    {
                        cmd.Parameters.AddWithValue(parameters[i].ParameterName.ToString(), parameters[i].Value);
                    }
                    using (MySqlDataAdapter sda = new MySqlDataAdapter(cmd))
                    {
                        var ds = new DataSet();
                        sda.Fill(ds);
                        con.Close();
                        return ds;
                    }
                }
            }
        }
    }
}

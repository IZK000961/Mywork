﻿using sqy.consumer.Helper;
using System;
using System.Collections.Generic;
using System.Text;

namespace sqy.consumer.DataAccess
{
    public abstract class DA
    {
        public MySqlDbHelper mySqlDbHelper { get; set; }
        public string connectionName { get; set; }
        public string connectionString { get; set; }
        public DA(string connectionName)
        {
            this.connectionName = connectionName;
            this.connectionString = AppSettingsConf.GetConnectionString(this.connectionName);
            mySqlDbHelper = new MySqlDbHelper(connectionString);
        }
    }
}

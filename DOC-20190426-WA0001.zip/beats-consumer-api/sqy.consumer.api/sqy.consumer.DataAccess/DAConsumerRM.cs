﻿using MySql.Data.MySqlClient;
using sqy.consumer.DataEntities;
using sqy.consumer.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace sqy.consumer.DataAccess
{
    public class DAConsumerRM 
    {
        public MySqlDbHelper mySqlDbHelper { get; set; }
        public DAConsumerRM(string connectionName = "beats") 
        {
            var connectionString = AppSettingsConf.GetConnectionString(connectionName);
            mySqlDbHelper = new MySqlDbHelper(connectionString);
        }
        public DataSet Execute(DEConsumerRM de)
        {
            var parameters = new List<MySqlParameter>();
            mySqlDbHelper.SetParameters(parameters, "_CallValue", MySqlDbType.Int32, de.CallValue);
            mySqlDbHelper.SetParameters(parameters, "_PageNo", MySqlDbType.Int32, de.PageNo);
            mySqlDbHelper.SetParameters(parameters, "_Limit", MySqlDbType.Int32, de.Limit);
            mySqlDbHelper.SetParameters(parameters, "_LeadID", MySqlDbType.VarChar, de.LeadID);
            mySqlDbHelper.SetParameters(parameters, "_Lead_hash", MySqlDbType.VarChar, de.lead_hash);
            mySqlDbHelper.SetParameters(parameters, "_RmId", MySqlDbType.Int32, de.RMId);
            mySqlDbHelper.SetParameters(parameters, "_Reason", MySqlDbType.VarChar, de.ChangeReason);
            mySqlDbHelper.SetParameters(parameters, "_SubReason", MySqlDbType.VarChar, de.SubReason);
            mySqlDbHelper.SetParameters(parameters, "_Remarks", MySqlDbType.VarChar, de.Remarks);
            mySqlDbHelper.SetParameters(parameters, "_NextInteractionDate", MySqlDbType.DateTime, de.NextInteractionDate);
            //mySqlDbHelper.SetParameters(parameters, "_UpdatedBy", MySqlDbType.DateTime, de.Updatedby);
            mySqlDbHelper.SetParameters(parameters, "_RecNo", MySqlDbType.Int32, de.ActivityId);
            mySqlDbHelper.SetParameters(parameters, "_ConsumerRating", MySqlDbType.Int32, de.FeedbackRatings);
            mySqlDbHelper.SetParameters(parameters, "_Type", MySqlDbType.Text, de.Type);

            mySqlDbHelper.SetParameters(parameters, "_RatingID", MySqlDbType.Int32, de.RatingID);
            mySqlDbHelper.SetParameters(parameters, "_RatingDesc", MySqlDbType.VarChar, de.RatingDesc);
            mySqlDbHelper.SetParameters(parameters, "_RatingValue", MySqlDbType.Double, de.RatingValue);

            mySqlDbHelper.SetParameters(parameters, "_FeedbackID", MySqlDbType.Int32, de.FeedbackID);
            mySqlDbHelper.SetParameters(parameters, "_FeedbackDesc", MySqlDbType.VarChar, de.FeedbackDesc);
            mySqlDbHelper.SetParameters(parameters, "_RmRatingId", MySqlDbType.Int32, de.RmRatingId);
            mySqlDbHelper.SetParameters(parameters, "_ChangeRM", MySqlDbType.Int16, de.ChangeRM);
            de.dsResult = mySqlDbHelper.Execute("udsp_ConsumerApiRM", parameters);
            return de.dsResult;
        }

        
    }
}
